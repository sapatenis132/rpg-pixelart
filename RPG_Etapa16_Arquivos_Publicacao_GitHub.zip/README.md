# RPG Pixel Art — Etapa 16

**Jogo 2D isométrico pixel art, horizontal**, com combate, combos, parry, esquiva, arena, treinamento e chefe. Mana 60/60 (ainda sem uso).

## Publicar no GitHub Pages (primeira vez pelo celular)

1. Se quiser publicar rapidamente, envie **somente `index.html`** na raiz do repositório. Ele contém o jogo inteiro, incluindo sprites provisórios, e não precisa de outros arquivos.
2. No repositório, abra **Settings > Pages** e escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`; clique **Save**.
3. Acesse `https://sapatenis132.github.io/rpg-pixelart/` depois que o GitHub Pages mostrar o status de publicação.
4. Em atualizações futuras, o arquivo publicado pode ser substituído sem alterar o endereço.

## Estrutura de desenvolvimento

- `index.html`: versão autônoma pronta para hospedagem.
- `index_modular.html`, `style.css`, `game.js`, `assets/`: versão modular do mesmo protótipo, preservada para desenvolvimento.
- `src/`: motor dividido por domínio (estado/combate, IA, simulação, pixel art/renderização, entrada/loop).
- `montar.py`: script para concatenar módulos em `game.js`.

O site ainda usa JavaScript e Canvas 2D (não Phaser). A arte é provisória.
