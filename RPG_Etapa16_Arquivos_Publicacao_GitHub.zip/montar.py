from pathlib import Path
root=Path(__file__).parent
files=['01_combate_e_estado.js','02_inteligencia.js','03_simulacao.js','04_pixel_art_e_renderizacao.js','05_controles_e_loop.js']
(root/'game.js').write_text(''.join((root/'src'/f).read_text() for f in files))
print('game.js atualizado')
