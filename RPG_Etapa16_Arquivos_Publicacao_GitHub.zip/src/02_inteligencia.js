function activeAttackers(){return living().filter(e=>['windup','strike','feint'].includes(e.phase)).length;}
function tacticalOn(){return settings.tactics && squadSize>1 && living().length>1;}
function squadRoles(){
 for(const e of enemies){e.role=e.style==='guardian'?'guardião':e.style==='duelist'?'flanco':e.slot%2?'flanco':'pressão';e.flankSide=e.slot%2?-1:1;
 e.flankComplete=0;e.flankCooldown=0;e.guardAlly=null;e.coverCooldown=.4+e.slot*.23;e.attackReady=0;e.allyDownReaction=0;e.tacticPulse=0;e.guardCounter=0;}
}
function coverFor(target){
 if(!tacticalOn())return null;
 return living().find(g=>g.id!==target.id&&g.style==='guardian'&&g.phase==='guard'&&g.guardTime>0&&g.guardAlly===target.id&&length(g.x-target.x,g.z-target.z)<2.42&&length(g.x-player.x,g.z-player.z)<3.6)||null;
}
function onAllyFallen(fallen){
 for(const e of living())if(e.id!==fallen.id&&length(e.x-fallen.x,e.z-fallen.z)<4.2){
  e.allyDownReaction=.42;e.cooldown=Math.max(e.cooldown,.42);e.guardAlly=null;
 }
}
function tacticalReadout(){
 const a=activeAttackers(),n=living().length;
 const status=document.getElementById('squadStatus');if(!status)return;
 status.textContent=squadSize===1?'DUELO · 1 × 1':!settings.tactics?'IA CLÁSSICA · '+n+' ADVERSÁRIOS':`ESQUADRÃO · ${a}/2 ATACANDO`;
 status.classList.toggle('disabled',!settings.tactics||squadSize===1);
}

function living(){return enemies.filter(e=>e.hp>0);}
function focus(){const alive=living(); if(!alive.length)return null;return alive.find(e=>e.id===focusId)||alive.slice().sort((a,b)=>length(a.x-player.x,a.z-player.z)-length(b.x-player.x,b.z-player.z))[0];}
function chooseTarget(force=false){const alive=living();if(!alive.length){enemy=null;focusId=null;return;}
 const v=movement(),moving=length(v.x,v.z)>.18,base=moving?unit(v.x,v.z):player.face;
 const eligible=alive.map(e=>{const d=length(e.x-player.x,e.z-player.z),to=unit(e.x-player.x,e.z-player.z),dot=to.x*base.x+to.z*base.z;return{e,d,dot,score:d+(moving?(1-dot)*2.7:0)};});
 const nearest=eligible.slice().sort((a,b)=>a.score-b.score)[0];
 const pinned=eligible.find(a=>a.e.id===focusId);
 if(force||!pinned||moving&&pinned.dot<.26&&nearest.dot>.42&&nearest.score+.35<pinned.score){focusId=nearest.e.id;}
 enemy=alive.find(e=>e.id===focusId)||nearest.e;
}
function cycleTarget(){const alive=living().sort((a,b)=>a.id-b.id);if(alive.length<2)return;const current=alive.findIndex(e=>e.id===focusId);focusId=alive[(current+1)%alive.length].id;chooseTarget();label('FOCO: '+enemy.title,1.0);updateFoePicker();}
function spawnWave(){enemies=[];let ids=eliteMode?[3]:drill.active?[drill.foe]:squadSize===1?[selectedEnemy]:squadSize===3?[0,1,2]:[0,1,2,1,2];const spots=[{x:2.45,z:-.8},{x:-2.6,z:-1.95},{x:2.5,z:2.45},{x:-3.9,z:2.5},{x:4.5,z:-3.2}];
 for(let i=0;i<ids.length;i++){let e=makeEnemy(ids[i]);e.id=++nextEnemyId;e.slot=i;e.x=clamp(player.x+spots[i].x,-6.1,6.1);e.z=clamp(player.z+spots[i].z,-6.1,6.1);if(ids.length>=5){e.hp=Math.round(e.hp*.79);e.maxHp=e.hp;e.balance=Math.round(e.balance*.85);e.maxBalance=e.balance;}e.cooldown+=i*.34;if(eliteMode){e.x=player.x+2.95;e.z=player.z-.5;e.cooldown=1.05;e.bossStage=1;e.bossCycle=0;e.bossWeak=0;e.bossQueue=[];e.bossPattern='';e.bossExposed=0;e.bossPhaseFlash=0;e.bossMemory={type:null,streak:0,last:-10};e.bossAdapt=0;e.bossAdaptiveCount=0;}if(drill.active){e.x=player.x+1.85;e.z=player.z;e.face={x:-1,z:0};e.hp=Math.round(FOES[drill.foe].life*1.75);e.maxHp=e.hp;e.cooldown=.8;}enemies.push(e);}
 focusId=null;enemy=enemies[0];updateEliteUI();waveStart=clock;waveStartDamage=totalDamage;waveStartTaken=totalTaken;waveStartParries=totalParries;waveStartSwings=totalSwings;waveStartSuccess=successfulSwings;squadRoles();lastAttackOrdered=-10;chooseTarget(true);updateFoePicker();tacticalReadout();}
function changeMode(){if(eliteMode){toggleElite();return;}if(drill.active){openLab();return;}squadSize=squadSize===3?5:squadSize===5?1:3;reset();note(squadSize===1?'TREINO INDIVIDUAL':squadSize===3?'TRIO DE ADVERSÁRIOS':'HORDA DE CINCO','Cada estilo mantém seu padrão de combate',1.5);}

let precisionHits=0,precisionMisses=0;
const smooth01=t=>{t=clamp(t,0,1);return t*t*(3-2*t)};
const rotate=(v,a)=>({x:v.x*Math.cos(a)-v.z*Math.sin(a),z:v.x*Math.sin(a)+v.z*Math.cos(a)});
function distanceToSegment(x,z,ax,az,bx,bz){const vx=bx-ax,vz=bz-az,t=clamp(((x-ax)*vx+(z-az)*vz)/(vx*vx+vz*vz||1),0,1);return length(x-(ax+vx*t),z-(az+vz*t));}
function activeInterval(move){return{start:Math.max(.09,move.impact-.18),end:Math.min(.79,move.impact+.18)};}
function swingPose(move,progress){const b=activeInterval(move),pct=(progress-b.start)/(b.end-b.start),s=smooth01(pct);
  return{fraction:clamp(pct,0,1),angle:mix(-1.05,1.05,s)*(move.angle||1),active:progress>=b.start&&progress<=b.end};
}
// The collision is a swept capsule along the visible weapon's world-space arc.
// Sampling between fixed simulation ticks prevents fast slashes from tunneling through a target.
function bladeTouch(a,prevProgress,nowProgress,foe){
 if(!foe||foe.hp<=0||foe.iframe>0)return false;
 const m=a.move,b=activeInterval(m);
 if(nowProgress<b.start||prevProgress>b.end)return false;
 const dist=length(foe.x-player.x,foe.z-player.z);
 if(dist>m.reach+.41)return false;
 const to=unit(foe.x-player.x,foe.z-player.z);
 if(to.x*player.face.x+to.z*player.face.z<-.13)return false;
 const begin=clamp(prevProgress,b.start,b.end),end=clamp(nowProgress,b.start,b.end);
 for(let k=0;k<=5;k++){
  const p=begin+(end-begin)*k/5,dir=rotate(player.face,swingPose(m,p).angle);
  const inner=.34,reach=m.reach+.07;
  const ax=player.x+dir.x*inner,az=player.z+dir.z*inner;
  const bx=player.x+dir.x*reach,bz=player.z+dir.z*reach;
  const allowance=.41+(m.fin?.14:.10);
  if(distanceToSegment(foe.x,foe.z,ax,az,bx,bz)<=allowance)return true;
 }
 return false;
}

const defaults={sound:true,haptics:true,dynamicCamera:true,reducedMotion:false,economy:false,sensitivity:1,showFps:false,showReach:false,tactics:true,difficulty:'balanced'};
let settings={...defaults};
try{const previous=JSON.parse(localStorage.getItem('iso_rpg_etapa8_settings')||'{}');if(previous&&typeof previous==='object')settings={...defaults,...previous};}catch(e){}
settings.sensitivity=clamp(Number(settings.sensitivity)||1,.65,1.40);if(!BALANCE[settings.difficulty])settings.difficulty='balanced';
let audioContext=null,noiseBuffer=null;
let totalHits=0,totalDamage=0,totalParries=0,totalDodges=0,totalTaken=0;
let frameAccumulator=0,fpsFrames=0,fpsTime=0,actualFps=0,lastRender=0;
const options=$('options'),stats=$('trainingStats');
function saveSettings(){try{localStorage.setItem('iso_rpg_etapa8_settings',JSON.stringify(settings));}catch(e){}}
function updateSettings(){
 for(const [id,key] of [['soundToggle','sound'],['hapticToggle','haptics'],['cameraToggle','dynamicCamera'],['motionToggle','reducedMotion'],['economyToggle','economy'],['fpsToggle','showFps'],['reachToggle','showReach'],['tacticsToggle','tactics']]){
  const b=$(id);b.textContent=settings[key]?'LIGADO':'DESLIGADO';b.setAttribute('aria-pressed',String(!!settings[key]));b.classList.toggle('enabled',!!settings[key]);
 }
 $('sensitivity').value=String(settings.sensitivity);$('sensitivityNumber').textContent=Math.round(settings.sensitivity*100)+'%';
 $('fpsPanel').style.display=settings.showFps?'block':'none';updateDifficultyUI();updateTrainingReadout();
 stats.textContent=`Alvos atingidos: ${totalHits}  •  Dano: ${totalDamage}  •  Parries: ${totalParries}  •  Esquivas: ${totalDodges}  •  Flancos: ${totalFlanks}  •  Coberturas: ${totalCovers}  •  Contra-ataques: ${totalPunishes}  •  Ondas: ${wavesCleared}  •  Precisão: ${trainingAccuracy()}%  •  Parries tentados: ${parryAttempts}  •  Falhas no parry: ${parryMisses}  •  Esquivas eficazes: ${dodgeSaves}  •  Maior combo: ${maxChain}`;
}
function toggleSetting(key){settings[key]=!settings[key];if(key==='tactics'){for(const e of living()){e.guardAlly=null;e.flankComplete=0;e.flankCooldown=0;e.guardCounter=0;}label(settings.tactics?'TÁTICA DE GRUPO ATIVADA':'IA CLÁSSICA ATIVADA',1.2);tacticalReadout();}if(key==='economy')resize();if(key==='sound'&&settings.sound)unlockAudio();saveSettings();updateSettings();}
function openOptions(){keys.clear();joyReset();updateSettings();guide.classList.remove('open');options.classList.add('open');frameAccumulator=0;}
function closeOptions(){options.classList.remove('open');last=0;frameAccumulator=0;}
function unlockAudio(){if(!settings.sound)return;try{
 if(!audioContext){const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;audioContext=new Audio();}
 if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});
 }catch(e){audioContext=null;}
}
function soundTone(freq,duration,shape='triangle',volume=.055,endRatio=.48,delay=0){
 if(!audioContext||audioContext.state!=='running'||!settings.sound)return;
 try{const now=audioContext.currentTime+delay,osc=audioContext.createOscillator(),gain=audioContext.createGain();
 osc.type=shape;osc.frequency.setValueAtTime(Math.max(35,freq),now);osc.frequency.exponentialRampToValueAtTime(Math.max(35,freq*endRatio),now+duration);
 gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(Math.max(.0002,volume),now+.008);
 gain.gain.exponentialRampToValueAtTime(.0001,now+duration);osc.connect(gain);gain.connect(audioContext.destination);
 osc.start(now);osc.stop(now+duration+.01);}catch(e){}
}
function noise(duration=.11,highpass=450,volume=.036){
 if(!audioContext||audioContext.state!=='running'||!settings.sound)return;
 try{if(!noiseBuffer){const sr=audioContext.sampleRate;noiseBuffer=audioContext.createBuffer(1,Math.ceil(sr*.35),sr);const a=noiseBuffer.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1);}
 const now=audioContext.currentTime,source=audioContext.createBufferSource(),filter=audioContext.createBiquadFilter(),gain=audioContext.createGain();
 source.buffer=noiseBuffer;filter.type='highpass';filter.frequency.value=highpass;gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(volume,now+.01);gain.gain.exponentialRampToValueAtTime(.0001,now+duration);
 source.connect(filter);filter.connect(gain);gain.connect(audioContext.destination);source.start(now);source.stop(now+duration+.02);}catch(e){}
}
function sfx(what){if(!settings.sound)return;
 if(what==='light'){noise(.085,620,.027);soundTone(390,.075,'triangle',.024,.6);}
 else if(what==='heavy'){noise(.16,260,.040);soundTone(186,.18,'sawtooth',.047,.35);}
 else if(what==='impact'){noise(.09,250,.043);soundTone(140,.13,'triangle',.052,.27);}
 else if(what==='finisher'){noise(.20,350,.060);soundTone(155,.28,'sawtooth',.064,.22);soundTone(660,.22,'triangle',.026,.48,.035);}
 else if(what==='guard'){soundTone(510,.19,'triangle',.034,.85);soundTone(735,.14,'sine',.023,.6);}
 else if(what==='parry'){noise(.12,950,.045);soundTone(910,.22,'sine',.064,1.52);soundTone(1340,.17,'triangle',.035,.75,.045);}
 else if(what==='dodge'){noise(.17,950,.025);}
 else if(what==='hurt'){noise(.14,180,.053);soundTone(195,.28,'sawtooth',.05,.45);}
 else if(what==='ko'){soundTone(260,.30,'triangle',.050,.46);soundTone(490,.35,'sine',.034,.55,.07);}
}

const EXTENSIONS={LLL:'H',LLH:'L',LHL:'H',LHH:'L',HLL:'H',HLH:'L',HH:'L'};
const keyLabel=(k)=>k.split('').map(c=>c==='L'?'LEVE':'PESADO').join(' · ');
function resize(){const r=game.getBoundingClientRect();w=r.width;h=r.height;
 dpr=Math.min(window.devicePixelRatio||1,settings.economy?1:2);
 canvas.width=Math.max(1,Math.round(w*dpr));canvas.height=Math.max(1,Math.round(h*dpr));
 baseSx=clamp(Math.min(w/8.9,h/11),27,50);sx=baseSx*(cam?.zoom||1);sy=sx*.52;
}
window.addEventListener('resize',resize);
function makeEnemy(styleIndex=selectedEnemy){
 const profile=FOES[styleIndex];return{x:profile.id==='berserker'?3.60:2.45,z:-.8,hp:Math.round(profile.life*BALANCE[settings.difficulty].enemyHp),maxHp:Math.round(profile.life*BALANCE[settings.difficulty].enemyHp),balance:profile.balance,maxBalance:profile.balance,balanceTimer:0,face:{x:-1,z:0},phase:'chase',wind:0,windMax:.75,strike:0,strikeMax:0,recover:0,cooldown:(profile.id==='berserker'?.50:1.1)*BALANCE[settings.difficulty].cooldown,stun:0,flash:0,knockX:0,knockZ:0,walk:0,hit:false,attackCount:0,type:'light',style:profile.id,title:profile.title,color:profile.color,aiSpeed:profile.speed,preferred:profile.reach,air:0,airVel:0,downTimer:0,downTotal:0,getup:0,launchCount:0,reaction:0,reactionDir:1,moveMagnitude:0,guardTime:0,guardCooldown:1.8,evade:0,evadeCooldown:1.6,iframe:0,side:1,feintCount:0,choice:styleIndex};
}

function reset(){eliteVictory=false;game.classList.toggle('in-elite',eliteMode);$('eliteBtn').classList.toggle('active',eliteMode);$('eliteBtn').textContent=eliteMode?'↩ ARENA':'♛ ELITE';if(drill.active){drill.score=0;drill.errors=0;drill.unique=new Set();drill.done=false;drill.attacks=0;drill.last='Objetivo iniciado · observe os golpes';}totalFlanks=0;totalCovers=0;totalPunishes=0;peakAttackers=0;lastTacticBanner=-10;lastAttackOrdered=-10;lastAttackInput=-10;rejectedInputs=0;simultaneousInputs=0;acceptedInputs=0;precisionHits=0;precisionMisses=0;parryAttempts=0;parryMisses=0;dodgeSaves=0;totalSwings=0;successfulSwings=0;maxChain=0;damageTimeline=[];lastWave=null;waveStart=0;waveStartDamage=0;waveStartTaken=0;waveStartParries=0;waveStartSwings=0;waveStartSuccess=0;totalHits=0;totalDamage=0;totalParries=0;totalDodges=0;totalTaken=0;player={x:0,z:0,hp:100,maxHp:100,mp:60,maxMp:60,face:{x:1,z:0},assist:false,act:null,buffer:null,bufferTime:0,attackLock:0,seq:'',seqTimer:0,chainReady:false,dodgeFollowup:0,dodgeChain:false,parryWindow:0,parryRecovery:0,parryCooldown:0,riposte:0,invuln:0,dodge:0,dodgeCooldown:0,dodgeDir:{x:0,z:0},velX:0,velZ:0,flash:0,walk:0,knockX:0,knockZ:0,reaction:0,reactionDir:1,moveMagnitude:0};enemy=null;nextEnemyId=0;wavesCleared=0;cam={x:0,z:0,zoom:1};particles=[];texts=[];arcs=[];rings=[];flashes=[];specials=[];clock=0;shake=0;hitStop=0;screenFlash=0;kills=0;respawn=0;bannerTime=0;noticeTime=0;banner.classList.remove('visible');hintUI.textContent=eliteMode?'Dourado: parry · Vermelho: esquiva':'Ajuste a dificuldade em ⚖ · confira o relatório em ⚙';spawnWave();updateSettings();hud();if(drill.active){drill.start=clock;game.classList.add('in-drill');}drillRefresh();}
function updateFoePicker(){const b=$('enemyPicker');b.textContent=`⚔ ARENA: ${squadSize===1?'DUELO':squadSize+' INIMIGOS'} ↻`;b.style.color='#8cefe4';$('targetPicker').textContent='◎ FOCO: '+(enemy?.name||enemy?.title||'—');}
function switchFoe(){changeMode();}
function note(main,sub='',duration=1){banner.replaceChildren(document.createTextNode(main));if(sub){const sm=document.createElement('small');sm.textContent=sub;banner.append(sm);}banner.classList.add('visible');bannerTime=duration;}
function label(s,time=1.15){hintUI.textContent=s;noticeTime=time;}
function buzz(ms){if(!settings.haptics)return;try{navigator.vibrate?.(ms)}catch(e){}}
function hud(){if(!player)return;hpFill.style.width=player.hp/player.maxHp*100+'%';mpFill.style.width=player.mp/player.maxMp*100+'%';hpText.textContent=Math.ceil(player.hp)+'/100';mpText.textContent=player.mp+'/60';
 let s='PRONTO PARA COMBATER';if(player.hp<=0)s='DERROTADO';else if(player.dodge>0)s='ESQUIVA';else if(player.riposte>0)s='RIPOSTA DISPONÍVEL!';else if(player.act?.move.fin)s=player.act.move.name;else if(player.seqTimer>0&&player.seq)s='COMBO: '+player.seq.split('').map(c=>c==='L'?'L':'P').join(' · ');else if(kills>0)s='DERROTADOS: '+kills+'  ·  EM CAMPO: '+living().length;comboUI.textContent=s;
 parryBtn.classList.toggle('cooling',player.parryCooldown>.08);parryBtn.classList.toggle('ready',player.parryCooldown<=.08);parryBtn.setAttribute('aria-label',player.parryCooldown>.08?'Parry recarregando':'Parry disponível');dodgeBtn.classList.toggle('cooling',player.dodgeCooldown>.05);dodgeBtn.classList.toggle('ready',player.dodgeCooldown<=.05);dodgeBtn.setAttribute('aria-label',player.dodgeCooldown>.05?'Esquiva recarregando':'Esquiva direcional disponível');
 $('queued').textContent=player.buffer?'↳ '+(player.buffer==='L'?'LEVE':'PESADO')+' NA FILA':'';
 const ext=player.chainReady&&EXTENSIONS[player.seq]&&player.seqTimer>0;
 const next=$('nextMove');next.textContent=ext?'COMBO EXTRA LIBERADO · '+(EXTENSIONS[player.seq]==='L'?'LEVE':'PESADO')+' → '+ATTACKS[player.seq+EXTENSIONS[player.seq]].name:(player.dodgeFollowup>0?'APÓS ESQUIVA · LEVE: PASSO / PESADO: INVESTIDA':'');next.classList.toggle('active',!!(ext||player.dodgeFollowup>0));}

function aimChoice(v=movement()){
 chooseTarget();
 const active=length(v.x,v.z)>.18,base=active?unit(v.x,v.z):player.face;
 if(!aimAssist||!enemy||enemy.hp<=0)return{dir:base,locked:false};
 const delta={x:enemy.x-player.x,z:enemy.z-player.z},dist=length(delta.x,delta.z);
 if(dist>4.10||dist<.02)return{dir:base,locked:false};
 const to=unit(delta.x,delta.z),forward=base.x*to.x+base.z*to.z;
 // Small sideways corrections are allowed, but pressing away ALWAYS takes precedence.
 if(active&&forward<.34)return{dir:base,locked:false};
 return{dir:to,locked:true};
}
function turnToward(dir,speed,dt){
 const from=Math.atan2(player.face.z,player.face.x),to=Math.atan2(dir.z,dir.x);
 const diff=Math.atan2(Math.sin(to-from),Math.cos(to-from));
 const ang=from+clamp(diff,-speed*dt,speed*dt);
 player.face={x:Math.cos(ang),z:Math.sin(ang)};
}
function faceEnemy(limit=3.3){ // Kept for parry facing, but honor player intention.
 const aim=aimChoice();
 if(aim.locked && enemy && length(enemy.x-player.x,enemy.z-player.z)<limit){player.face=aim.dir;player.assist=true;}
}

function separateActors(){
 for(const e of living()){let dx=player.x-e.x,dz=player.z-e.z,dist=length(dx,dz);const gap=.70;if(dist>=gap)continue;const a=unit(dx||.001,dz||.001),push=gap-dist;player.x=clamp(player.x+a.x*push*.57,-6.65,6.65);player.z=clamp(player.z+a.z*push*.57,-6.65,6.65);e.x=clamp(e.x-a.x*push*.43,-6.65,6.65);e.z=clamp(e.z-a.z*push*.43,-6.65,6.65);}
 for(let i=0;i<enemies.length;i++)for(let j=i+1;j<enemies.length;j++){
  const a=enemies[i],b=enemies[j];if(a.hp<=0||b.hp<=0)continue;
  const dx=a.x-b.x,dz=a.z-b.z,dist=length(dx,dz),gap=.73;if(dist>=gap)continue;
  const n=unit(dx||((i%2)*2-1)*.1,dz||((j%2)*2-1)*.1),push=(gap-dist)*.5;
  a.x=clamp(a.x+n.x*push,-6.65,6.65);a.z=clamp(a.z+n.z*push,-6.65,6.65);
  b.x=clamp(b.x-n.x*push,-6.65,6.65);b.z=clamp(b.z-n.z*push,-6.65,6.65);
 }
}
function dodge(){if(player.hp<=0||options.classList.contains('open')||guide.classList.contains('open')||$('drillPanel').classList.contains('open')||player.dodgeCooldown>0||player.dodge>0)return;
 const a=player.act;
 if(a&&!a.hit){label('Esquiva liberada após o impacto',.60);return;}
 const v=movement();const direction=length(v.x,v.z)<.12?{x:-player.face.x,z:-player.face.z}:unit(v.x,v.z);
 totalDodges++;sfx('dodge');player.dodge=.26;player.attackLock=0;player.dodgeCooldown=.58;player.dodgeDir=direction;player.invuln=Math.max(player.invuln,profile().dodgeIframes);
 player.velX=player.velZ=0;player.act=null;player.buffer=null;player.bufferTime=0;if(player.parryWindow>0)parryMisses++;player.parryWindow=0;player.parryRecovery=0;player.riposte=0;
 player.seq='';player.seqTimer=0;player.chainReady=false;player.dodgeFollowup=.68;player.dodgeChain=true;ring(player.x,player.z,'#c2b1ff',12,.4);burst(player.x,player.z,'#aa9cf6',8,.55);buzz(10);hud();
}

function burst(x,z,color,n=13,pow=1,up=35){n=Math.max(2,Math.round(n*(settings.economy?.50:1)));for(let i=0;i<n;i++){const a=rnd(0,TAU),v=rnd(.45,2.6)*pow;particles.push({x,z,y:rnd(18,41),vx:Math.cos(a)*v,vz:Math.sin(a)*v,vy:rnd(-40,-125)*pow,life:rnd(.25,.62),max:.62,size:rnd(1.7,3.8),color,trail:Math.random()<.5});}const maxParticles=settings.economy?90:200;if(particles.length>maxParticles)particles.splice(0,particles.length-maxParticles);}
function floating(t,x,z,color='#fff',size=17){texts.push({t,x,z,y:50,life:.86,max:.86,color,size});}
function ring(x,z,color,radius=12,power=1){rings.push({x,z,color,r:radius,life:.40,max:.40,power});}
function swipe(x,z,kind,face,angle,scale=1,opts={}){const life=opts.life??.22;arcs.push({x,z,kind,face:{...face},angle,life,max:life,scale,...opts});}
function paletteFor(move,key){
 if(move.rip)return{main:'#7dffe1',edge:'#f7fff9',glow:'#9cffef',flash:'#d8fff6',width:19,radius:62,life:.30,screen:.22,echo:'#d7fff3'};
 if(move.fin){
  if(move.ext)return{main:'#dc9dff',edge:'#fff1ff',glow:'#c89aff',flash:'#f5d7ff',width:23,radius:75,life:.36,screen:.29,echo:'#f0cfff'};
  if(key==='HLH' || key==='RIP_H')return{main:'#ffae5a',edge:'#fff0d5',glow:'#ffd171',flash:'#ffe5b0',width:22,radius:78,life:.36,screen:.36,echo:'#ffdca4'};
  if(key==='LLH' || key==='HH' || key==='LHH')return{main:'#ffd06d',edge:'#fff7d8',glow:'#ffe08e',flash:'#fff0ba',width:21,radius:72,life:.34,screen:.32,echo:'#ffe8b3'};
  if(key==='LHL')return{main:'#b6ff6c',edge:'#fbffe8',glow:'#d8ff97',flash:'#eeffc8',width:19,radius:66,life:.31,screen:.24,echo:'#ecffb5'};
  return{main:'#75e4ff',edge:'#f1ffff',glow:'#9ef6ff',flash:'#d2fbff',width:19,radius:68,life:.31,screen:.26,echo:'#ccfbff'};
 }
 if(key.includes('H'))return{main:'#ffb777',edge:'#fff0d9',glow:'#ffd09d',flash:'#ffe4c4',width:17,radius:54,life:.26,screen:.14,echo:'#ffe2bc'};
 return{main:'#6ddaff',edge:'#effbff',glow:'#8cecff',flash:'#dcf9ff',width:13,radius:44,life:.22,screen:.08,echo:'#c8f4ff'};
}
function flashAt(x,z,color,power=1,life=.20){flashes.push({x,z,color,power,life,max:life});if(flashes.length>28)flashes.splice(0,flashes.length-28);screenFlash=Math.max(screenFlash,.08*power);} 
function directionalBurst(x,z,dir,color,power=1,count=10){count=Math.max(2,Math.round(count*(settings.economy?.5:1)));const ang=Math.atan2(dir.z,dir.x);for(let i=0;i<count;i++){const a=ang+rnd(-.65,.65),v=rnd(1.1,3.8)*power;particles.push({x,z,y:rnd(16,34),vx:Math.cos(a)*v,vz:Math.sin(a)*v,vy:rnd(-160,-30)*.22,life:rnd(.16,.36),max:.36,size:rnd(1.2,3.2),color,trail:true});}}
function impactFX(x,z,dir,pal,power=1,fin=false){burst(x,z,pal.main,Math.round(12*power),.9*power);burst(x,z,pal.edge,Math.round(7*power),.75*power);directionalBurst(x,z,dir,pal.edge,1.15*power,Math.round(9*power));ring(x,z,pal.main,13+7*power,.6*power);flashAt(x,z,pal.flash,fin?1.4*power:.9*power,fin?.26:.18);}
function finisherFX(x,z,dir,pal,key='LLL'){
 // Big hits need distinct silhouettes: swirl, cross-cut, pillar, successive cuts, execution.
 const side={x:-dir.z,z:dir.x};
 const fast=key==='LLL'||key==='LHL'||key==='HLL'||key==='RIP_L';
 if(['LLL','HLL','LHH','HH'].includes(key))swipe(x-dir.x*.10,z-dir.z*.10,'finisher',{x:dir.x+side.x*.10,z:dir.z+side.z*.10},1,fast?.90:.97,{life:.24,color:pal.main,edge:pal.edge,width:pal.width*.72,radius:pal.radius*.66,glow:pal.glow});
 if(key==='LLL'||key==='HLL')swipe(x+dir.x*.08,z+dir.z*.08,'finisherEcho',{x:dir.x-side.x*.13,z:dir.z-side.z*.13},-1,.92,{life:.27,color:pal.echo,edge:'#ffffff',width:Math.max(6,pal.width-9),radius:pal.radius*.69,glow:pal.glow});
 specials.push({x,z,dir:{...dir},kind:key,life:key==='HLH'?.56:.44,max:key==='HLH'?.56:.44,color:pal.main,edge:pal.edge,glow:pal.glow});
 if(specials.length>16)specials.shift();
 ring(x,z,pal.edge,20,1.16);ring(x,z,pal.main,14,1);
 burst(x,z,pal.edge,18,1.18);directionalBurst(x,z,dir,pal.main,1.35,15);
 flashAt(x,z,pal.flash,1.7,.25);screenFlash=Math.max(screenFlash,pal.screen);
}
// Etapa 15: única entrada válida por golpe, sem ganho por pressionar L/P simultaneamente.
const INPUT_DEBOUNCE=.105,BUFFER_START=.43,BUFFER_END=.93;
let lastAttackInput=-10,rejectedInputs=0,simultaneousInputs=0,acceptedInputs=0;
function attackWindow(a){if(!a)return false;const t=a.time/a.move.dur;return t>=BUFFER_START&&t<=BUFFER_END;}
function readyForNext(){return player.hp>0&&player.dodge<=0&&player.parryRecovery<=0&&player.attackLock<=0&&!player.act;}
function rhythmReadout(){const el=$('rhythmHud');if(!el)return;
 const a=player.act,ready=a&&attackWindow(a)&&!player.buffer;
 el.classList.toggle('ready',!!ready);el.classList.toggle('waiting',!!a&&!ready);
 el.textContent=a?.mashed?'EXCESSO DE TOQUES · COMBO PERDIDO':player.buffer?'↳ '+(player.buffer==='L'?'LEVE':'PESADO')+' AGENDADO':ready?'✦ JANELA DE COMBO · escolha L ou P':a?'COMPASSO · aguarde a abertura':player.attackLock>0?'RECUPERAÇÃO · reposicione-se':'COMPASSO · um toque por golpe';
}

function startAttack(type){
 const aim=aimChoice();player.face=aim.dir;player.assist=aim.locked;
 let key;
 if(player.riposte>0){key=type==='L'?'RIP_L':'RIP_H';player.riposte=0;player.seq='';player.seqTimer=0;player.chainReady=false;}
 else if(player.dodgeChain&&player.dodgeFollowup>0){key=type==='L'?'DASH_L':'DASH_H';player.seq='';player.seqTimer=0;player.chainReady=false;}
 else{
  const prior=player.seqTimer>0?player.seq:'';
  let next=prior+type;
  if(prior&&ATTACKS[prior]?.fin&&(!player.chainReady||EXTENSIONS[prior]!==type))next=type;
  if(next.length>4||!ATTACKS[next])next=type;
  key=next;player.seq=next;player.seqTimer=1.30;player.chainReady=false;
 }
 player.dodgeFollowup=0;player.dodgeChain=false;
 const move=ATTACKS[key],pal=paletteFor(move,key);totalSwings++;maxChain=Math.max(maxChain,/^[LH]+$/.test(key)?key.length:1);
 player.act={key,move,time:0,hit:false,landed:false,pal,previousProgress:0,hitIds:new Set(),slashed:false,finishedArc:false,mashCount:0,mashed:false};player.attackLock=0;acceptedInputs++;sfx(key.includes('H')?'heavy':'light');player.buffer=null;player.bufferTime=0;
 burst(player.x,player.z,pal.main,4,.45);directionalBurst(player.x,player.z,player.face,pal.edge,.65,5);
 if(move.ext||move.dash)label(move.name+'!',.85);
 if(move.fin){flashAt(player.x,player.z,pal.flash,.9,.18);label(move.name+'!',.8);}hud();
}

function attack(type){
 if(player.hp<=0||guide.classList.contains('open')||options.classList.contains('open')||$('drillPanel').classList.contains('open'))return;
 // Two fingers/buttons fired together cannot cause two attacks or overwrite an ordered action.
 if(clock-lastAttackInput<INPUT_DEBOUNCE){simultaneousInputs++;
  if(player.act){player.act.mashCount++;if(player.act.mashCount>=4){player.act.mashed=true;player.buffer=null;player.bufferTime=0;}}
  return;}
 lastAttackInput=clock;
 if(player.dodge>0||player.parryRecovery>0){rejectedInputs++;return;}
 if(player.act){
  const a=player.act;
  if(a.mashed){rejectedInputs++;return;}
  if(!attackWindow(a)||player.buffer){
   rejectedInputs++;a.mashCount++;
   if(a.mashCount>=4){a.mashed=true;player.buffer=null;player.bufferTime=0;label('COMBO INTERROMPIDO · espere a janela verde',.8);}
   return;
  }
  player.buffer=type;player.bufferTime=.75;hud();return;
 }
 if(player.attackLock>0){rejectedInputs++;return;}
 if(player.parryWindow>0){parryMisses++;player.parryWindow=0;player.parryRecovery=.05;}
 startAttack(type);
}

function parry(){if(player.hp<=0||options.classList.contains('open')||guide.classList.contains('open')||$('drillPanel').classList.contains('open')||player.parryCooldown>0||player.dodge>0)return;
 if(player.act&&!player.act.hit){label('Parry após a execução do golpe',.48);return;}
 faceEnemy(2.8);parryAttempts++;player.parryWindow=profile().parry;player.attackLock=0;player.parryRecovery=.34;player.parryCooldown=.78;player.act=null;player.buffer=null;player.bufferTime=0;player.chainReady=false;player.dodgeFollowup=0;player.dodgeChain=false;player.flash=.09;sfx('guard');ring(player.x,player.z,'#74ffe1',16,.7);burst(player.x,player.z,'#9efce9',6,.55);label('PARRY! Acerte o instante do impacto.',.65);buzz(9);hud();}
function perfectParry(){if(enemy?.style==='elite'){enemy.bossWeak=1.8;enemy.bossQueue=[];enemy.bossPattern='';}focusId=enemy.id;totalParries++;drillEvent('parry');
 if(tacticalOn()){
  for(const other of living())if(other!==enemy&&other.phase==='windup'&&length(other.x-player.x,other.z-player.z)<3.15){
   other.wind+=.31;other.windMax+=.31;other.tacticPulse=.5;
  }
  floating('BRECHA NO CERCO',player.x,player.z,'#b5ffef',12);
 }
sfx('parry');player.parryWindow=0;player.parryRecovery=.08;player.parryCooldown=.33;player.riposte=1.45;player.invuln=.22;player.seq='';player.seqTimer=0;player.chainReady=false;player.dodgeFollowup=0;player.dodgeChain=false;player.act=null;player.buffer=null;player.bufferTime=0;enemy.phase='stun';enemy.wind=0;enemy.strike=0;enemy.stun=1.38;enemy.knockX-=enemy.face.x*2.9;enemy.knockZ-=enemy.face.z*2.9;enemy.flash=.24;
 hitStop=.068;shake=12;ring(player.x,player.z,'#e5fff4',22,2.1);ring(enemy.x,enemy.z,'#9dffdc',28,1.4);burst((player.x+enemy.x)/2,(player.z+enemy.z)/2,'#e4ffba',34,1.65);flashAt(enemy.x,enemy.z,'#e9fff6',1.6,.26);directionalBurst(enemy.x,enemy.z,{x:-enemy.face.x,z:-enemy.face.z},'#dcfff2',1.4,18);floating('PARRY PERFEITO!',enemy.x,enemy.z,'#a9ffda',18);screenFlash=Math.max(screenFlash,.22);note('PARRY PERFEITO!','Leve ou pesado para ripostar',1.2);buzz(27);hud();}
function playerHit(contact=false,target=null){
 const currentEnemy=enemy;if(target)enemy=target;
 try{
 const a=player.act;if(!a||target&&a.hitIds.has(target.id)||!target&&a.finishedArc)return;
 if(target)a.hitIds.add(target.id);else a.finishedArc=true;
 a.hit=true;
 const showSlash=!a.slashed;a.slashed=true;
 const move=a.move,pal=a.pal||paletteFor(move,a.key);
 if(showSlash)swipe(player.x,player.z,move.rip?'rip':a.key.includes('H')?'heavy':'light',player.face,move.angle,move.fin?.93:1,{life:pal.life,color:pal.main,edge:pal.edge,width:move.fin?pal.width*.8:pal.width,radius:move.fin?pal.radius*.90:pal.radius,glow:pal.glow});
 if(showSlash&&move.fin&&['LLL','HLL','LHH'].includes(a.key))swipe(player.x,player.z,'finPrep',player.face,-move.angle*.6,.81,{life:pal.life*.67,color:pal.echo,edge:'#ffffff',width:Math.max(6,pal.width-9),radius:pal.radius*.7,glow:pal.glow});
 if(!enemy||enemy.hp<=0){ring(player.x+player.face.x,player.z+player.face.z,pal.main,10,.2);if(move.fin){player.seq='';player.seqTimer=0;player.chainReady=false;}return;}
 const dx=enemy.x-player.x,dz=enemy.z-player.z,d=length(dx,dz),dir=unit(dx,dz),dot=dir.x*player.face.x+dir.z*player.face.z;
 if(!contact||d>move.reach+.41||dot<-.13){
  burst(player.x+player.face.x,player.z+player.face.z,pal.echo,5,.55);
  directionalBurst(player.x+player.face.x*.6,player.z+player.face.z*.6,player.face,pal.main,.55,6);
  precisionMisses++;if(move.fin){player.seq='';player.seqTimer=0;player.chainReady=false;}return;
 }
 if(enemy.iframe>0){floating('ESQUIVA!',enemy.x,enemy.z,'#ddbbff',15);burst(enemy.x,enemy.z,'#c3a4ff',10,.8);if(move.fin){player.seq='';player.seqTimer=0;player.chainReady=false;}return;}
 if(!a.landed){successfulSwings++;drillEvent('landed',a.key);
  if(enemy.style==='elite'&&enemy.bossMemory){const group=a.key.includes('H')?'H':'L',m=enemy.bossMemory;
   m.streak=group===m.type&&clock-m.last<4.0?m.streak+1:1;m.type=group;m.last=clock;
   if(m.streak>=3){enemy.bossAdapt=1.6;enemy.bossAdaptiveCount++;m.streak=0;floating('PADRÃO LIDO!',enemy.x,enemy.z,'#ffd19a',14);}}
 }a.landed=true;if(a.hitIds.size>=2)floating('MULTIACERTO x'+a.hitIds.size,player.x,player.z,'#b3ffe3',15);
 const guarding=enemy.phase==='guard'&&enemy.guardTime>0;
 const airborne=enemy.air>.05,downed=enemy.downTimer>0;
 const multiplier=move.execute&&downed?1.42:move.airBonus&&airborne?1.35:1;
 const allyGuard=!guarding?coverFor(enemy):null;
 const bossBonus=enemy.style==='elite'&&enemy.bossWeak>0?1.35:1;const dmg=Math.max(1,Math.round(move.dmg*multiplier*bossBonus*(guarding?.24:allyGuard?.64:1)));
 if(allyGuard){allyGuard.balance=Math.max(0,allyGuard.balance-20);allyGuard.balanceTimer=1.1;totalCovers++;floating('COBERTURA!',enemy.x,enemy.z,'#a9ffdf',14);ring(allyGuard.x,allyGuard.z,'#8cefe0',17,.75);
  if(allyGuard.balance<=0){allyGuard.balance=allyGuard.maxBalance;allyGuard.phase='stun';allyGuard.stun=1.2;allyGuard.guardAlly=null;floating('ESCUDO ROMPIDO!',allyGuard.x,allyGuard.z,'#ffe4a1',13);}
 }

 if(guarding){sfx('guard');floating('BLOQUEIO!',enemy.x,enemy.z,'#8bfff0',13);ring(enemy.x,enemy.z,'#87fff2',15,.9);shake=3;}
 enemy.hp=Math.max(drill.active?1:0,enemy.hp-dmg);if(drill.active&&enemy.hp<enemy.maxHp*.16)enemy.hp=enemy.maxHp;totalHits++;precisionHits++;totalDamage+=dmg;damageTimeline.push({t:clock,d:dmg});if(damageTimeline.length>500)damageTimeline.splice(0,100);enemy.flash=.19;enemy.reaction=.25;enemy.reactionDir=move.angle||1;
 const pressure=(move.break?95:move.fin?76:move.rip?75:a.key.includes('H')?44:27)*(guarding?1.22:1)*(enemy.style==='elite'?.75:1);
 enemy.balance=Math.max(0,enemy.balance-pressure);enemy.balanceTimer=1.25;
 const broken=enemy.balance<=0;
 if(broken){if(enemy.style==='elite'){enemy.bossWeak=2.3;enemy.bossQueue=[];floating('POSTURA ROMPIDA! +35% DANO',enemy.x,enemy.z,'#ffe4a4',13);}enemy.balance=enemy.maxBalance;enemy.cooldown=.90;enemy.guardTime=0;enemy.stun=Math.max(enemy.stun,.85);if(!airborne&&!downed)enemy.phase='stun';floating('GUARDA QUEBRADA',enemy.x,enemy.z,'#ffe9a4',13);}
 else if(enemy.phase==='chase')enemy.cooldown=Math.max(enemy.cooldown,.19);
 let effectText='';
 if(guarding&&!broken){enemy.guardTime=Math.max(0,enemy.guardTime-.23);effectText='ESCUDO SEGURA O GOLPE';}
 else if(move.launch&&(enemy.style!=='elite'||broken)){enemy.downTimer=0;enemy.getup=0;enemy.air=Math.max(enemy.air,.09);enemy.airVel=4.7;enemy.launchCount++;enemy.stun=0;enemy.phase='air';effectText='LANÇADO!';}
 else if(move.slam&&(airborne||downed)&&(enemy.style!=='elite'||broken)){enemy.air=0;enemy.airVel=0;enemy.downTimer=1.12;enemy.downTotal=1.12;enemy.stun=0;enemy.phase='down';effectText='IMPACTO NO SOLO!';}
 else if(move.down&&(enemy.style!=='elite'||broken)){enemy.air=0;enemy.airVel=0;enemy.downTimer=1.06;enemy.downTotal=1.06;enemy.stun=0;enemy.phase='down';effectText='DERRUBADO!';}
 else if(move.vortex){enemy.knockX-=dir.x*4.1;enemy.knockZ-=dir.z*4.1;effectText='PUXÃO CIRCULAR';}
 else if(move.break){enemy.stun=Math.max(enemy.stun,1.02);enemy.phase='stun';effectText='ABERTURA NA GUARDA';}
 else if(airborne){enemy.airVel=Math.max(enemy.airVel,2.8);enemy.phase='air';effectText='CONTROLE AÉREO';}
 if(enemy.style==='elite'&&!broken&&(move.launch||move.down||move.slam))effectText='ELITE RESISTE · QUEBRE A POSTURA';if(move.execute&&downed){effectText='EXECUÇÃO +42%';}
 if(move.airBonus&&airborne){effectText='ATAQUE AÉREO +35%';}
 if(effectText){floating(effectText,enemy.x,enemy.z,'#b9f4ff',12);label(effectText,.75);}
 enemy.knockX+=dir.x*move.knock*(enemy.style==='elite'&&!broken?.27:broken?1.6:guarding?.10:1.10);enemy.knockZ+=dir.z*move.knock*(enemy.style==='elite'&&!broken?.27:broken?1.6:guarding?.10:1.10);
 impactFX(enemy.x,enemy.z,dir,pal,move.fin?1.7:move.dmg>20?1.2:1,move.fin);if(!guarding)sfx(move.fin?'finisher':'impact');
 if(move.fin)finisherFX(enemy.x,enemy.z,dir,pal,a.key);
 floating('-'+dmg,enemy.x,enemy.z,move.fin?pal.edge:'#e9fbff',move.fin?26:18);
 shake=move.fin?12:move.dmg>20?7:4;hitStop=move.fin?.075:.040;screenFlash=Math.max(screenFlash,pal.screen*(move.fin?1:.65));buzz(move.fin?31:12);
 if(enemy.hp<=0){onAllyFallen(enemy);sfx('ko');kills++;enemy.phase='dead';enemy.air=0;enemy.downTimer=0;floating('DERROTADO!',enemy.x,enemy.z,'#ffe0a4',16);if(living().length===0) {respawn=eliteMode?0:2.15;wavesCleared++;waveFinished();if(eliteMode){eliteVictory=true;note('SENTINELA DERROTADA!','Vitória! Toque em ↻ para repetir ou ↩ ARENA para sair.',999);label('DUELO CONCLUÍDO · HP '+Math.ceil(player.hp),2);}else note('ONDA CONCLUÍDA! · NOTA '+lastWave.grade,'Veja seu desempenho no menu ⚙',1.6);} else label('Inimigo derrotado · '+living().length+' restantes',1.1);}
 if(move.fin){
  if(living().length>0&&EXTENSIONS[a.key]&&!move.ext){player.seq=a.key;player.chainReady=true;player.seqTimer=1.14;}
  else {player.seq='';player.seqTimer=0;player.chainReady=false;}
 }
 hud();
} finally {enemy=currentEnemy;}
}

function enemyDamage(){
 if(!enemy||enemy.hp<=0||player.hp<=0)return;
 const dx=player.x-enemy.x,dz=player.z-enemy.z,dist=length(dx,dz),vec=unit(dx,dz);
 const range=enemy.style==='elite'?(enemy.type==='crush'?2.05:enemy.type==='thrust'?2.55:enemy.type==='dash'?1.70:2.1):enemy.type==='rush'?1.53:enemy.type==='heavy'?2.20:enemy.type==='quick'?1.78:1.93;
 const ahead=vec.x*enemy.face.x+vec.z*enemy.face.z;
 if(dist>range||ahead<(enemy.type==='crush'?.22:enemy.type==='thrust'?.68:enemy.type==='heavy'?.25:.40)){if(drill.active&&drill.mode==='dodge'&&player.dodge>0&&player.invuln>0&&dist<=range+1.5&&ahead>-.15){dodgeSaves++;drillEvent('dodge');}return;}
 if(player.parryWindow>0){if(enemy.style==='elite'&&enemy.type==='crush'){player.parryWindow=0;parryMisses++;label('RUPTURA: NÃO PODE SER APARADA!',.85);}else{perfectParry();return;}}
 if(player.invuln>0||player.dodge>0){if(player.dodge>0){dodgeSaves++;drillEvent('dodge');}return;}
 const baseDamage=enemy.style==='elite'?(enemy.type==='crush'?26:enemy.type==='thrust'?16:enemy.type==='dash'?18:14):enemy.type==='rush'?20:enemy.type==='heavy'?18:enemy.type==='quick'?10:12;const damage=Math.max(1,Math.round(baseDamage*profile().enemyDamage));
 player.hp=Math.max(drill.active?1:0,player.hp-damage);if(drill.active&&player.hp<=20){player.hp=100;drillFailure('Recebeu golpes; vida restaurada para continuar.');}totalTaken+=damage;sfx('hurt');player.flash=.27;player.reaction=.30;player.reactionDir=enemy.face.x*player.face.z-enemy.face.z*player.face.x<0?-1:1;player.invuln=profile().postHitIframes;
 player.knockX+=vec.x*3.9;player.knockZ+=vec.z*3.9;player.act=null;player.buffer=null;player.bufferTime=0;player.seq='';player.seqTimer=0;player.chainReady=false;player.dodgeChain=false;player.dodgeFollowup=0;player.riposte=0;
 shake=7;hitStop=.045;burst(player.x,player.z,'#ff8194',20,1.2);ring(player.x,player.z,'#ff6d81',20,.8);flashAt(player.x,player.z,'#ffd5dd',1.1,.18);floating('-'+damage,player.x,player.z,'#ff9cad',20);screenFlash=Math.max(screenFlash,.12);buzz(22);label('DANO RECEBIDO — veja o aviso do golpe!',1.15);
 if(player.hp<=0&&!drill.active)note('VOCÊ CAIU','Toque em ↻ ou aperte R para reiniciar',999);if(drill.active&&drill.mode==='dodge')drillFailure('Golpe conectado: experimente esquivar mais perto do impacto.');hud();
}

function movement(){let ix=input.x,iy=input.y;if(keys.has('a')||keys.has('arrowleft'))ix--;if(keys.has('d')||keys.has('arrowright'))ix++;if(keys.has('w')||keys.has('arrowup'))iy--;if(keys.has('s')||keys.has('arrowdown'))iy++;
 const raw=length(ix,iy),t=raw<.14?0:clamp((raw-.14)/.86,0,1);if(raw>1){ix/=raw;iy/=raw;}const vx=ix*.64+iy*1.04,vz=-ix*.64+iy*1.04,dir=unit(vx,vz);return{x:raw?dir.x*t:0,z:raw?dir.z*t:0};}
function beginEnemyWindup(attackType){
 if(!enemy||enemy.hp<=0)return;
 const attacking=enemies.filter(e=>e.hp>0&&e.id!==enemy.id&&['windup','strike','feint'].includes(e.phase)).length;
 if(attacking>=(squadSize>1?2:1)){enemy.cooldown=Math.max(enemy.cooldown,.32);return;}
 if(tacticalOn()&&clock-lastAttackOrdered<profile().tempo){enemy.cooldown=Math.max(enemy.cooldown,.18);return;}
 if(tacticalOn()){lastAttackOrdered=clock;enemy.tacticPulse=.55;}

 enemy.type=attackType;enemy.phase='windup';enemy.hit=false;
 const enraged=enemy.style==='berserker'&&enemy.hp<enemy.maxHp*.50;
 enemy.wind=attackType==='rush'?.83:attackType==='heavy'?.94:attackType==='quick'?.53:.70;
 if(enraged)enemy.wind=Math.max(.48,enemy.wind*.84);enemy.wind=Math.max(profile().minWind,enemy.wind*profile().windup);
 if(tacticalOn()&&attacking>0)enemy.wind+=.25; // second threat is deliberately staggered
 enemy.windMax=enemy.wind;enemy.attackCount++;peakAttackers=Math.max(peakAttackers,attacking+1);

 const aim=unit(player.x-enemy.x,player.z-enemy.z);enemy.face=aim;
 if(attackType==='rush')label('INVESTIDA! Saia da linha ou use parry!',.85);
}
// The elite uses a dedicated readable finite-state machine. No hidden, instant strikes.
function updateEliteUI(){
 const e=enemies.find(f=>f.style==='elite');
 const pane=$('eliteHud');if(!pane)return;
 if(!eliteMode||!e){pane.classList.remove('danger');return;}
 $('eliteHPFill').style.width=clamp(e.hp/e.maxHp*100,0,100)+'%';
 $('elitePoiseFill').style.width=clamp(e.balance/e.maxBalance*100,0,100)+'%';
 $('eliteStage').textContent='FASE '+(['','I','II','III'][e.bossStage||1])+' · '+Math.ceil(e.hp)+' HP';
 const danger=e.phase==='windup'&&e.type==='crush';
 pane.classList.toggle('danger',danger);
 let hint=e.hp<=0?'VITÓRIA! ↻ para repetir':e.bossWeak>0?'ABERTURA! +35% de dano até a recuperação':
 e.phase==='windup'?(danger?'VERMELHO · INAPARÁVEL · ESQUIVE!':e.type==='dash'?'ÂMBAR · INVESTIDA · DESVIE OU APARE':e.type==='thrust'?'DOURADO · ESTOCADA · PARRY':'DOURADO · CORTE · PARRY'):
 e.phase==='recover'?'RECUPERAÇÃO · MOMENTO DE PUNIR':'Observe a preparação para decidir sua defesa';
 $('eliteTell').textContent=hint;
}
function toggleElite(){
 if(drill.active){drill.active=false;game.classList.remove('in-drill');closeLab();}
 eliteMode=!eliteMode;eliteVictory=false;squadSize=eliteMode?1:3;selectedEnemy=eliteMode?3:0;reset();
 note(eliteMode?'DESAFIO DE ELITE · SENTINELA DO ECLIPSE':'ARENA NORMAL','Dourado: parry · Vermelho: esquiva',2.0);
}
function eliteBegin(e,type,chain=false){
 if(e.hp<=0)return;
 e.type=type;e.phase='windup';e.hit=false;e.bossPattern=type;
 let base=type==='crush'?1.13:type==='dash'?.91:type==='thrust'?.72:.68;
 const phaseScale=e.bossStage===3?.83:e.bossStage===2?.92:1;
 e.wind=Math.max(type==='crush'?.70:.48,base*phaseScale*profile().windup*(chain?.77:1));
 e.windMax=e.wind;e.attackCount++;
 e.face=unit(player.x-e.x,player.z-e.z);
 if(type==='crush'){label('GOLPE INAPARÁVEL! Esquive ou saia do alcance.',1.35);}
 else if(type==='dash'){label('INVESTIDA ELITE · observe a linha de ataque',1.0);}
 else if(chain){label('SEGUNDO GOLPE! Prepare o parry.',.65);}
}
function eliteBrain(dt){
 const e=enemy;if(!e||e.hp<=0)return;
 e.flash=Math.max(0,e.flash-dt);e.iframe=Math.max(0,e.iframe-dt);
 e.reaction=Math.max(0,(e.reaction||0)-dt);e.bossWeak=Math.max(0,(e.bossWeak||0)-dt);
 e.bossPhaseFlash=Math.max(0,(e.bossPhaseFlash||0)-dt);e.bossAdapt=Math.max(0,(e.bossAdapt||0)-dt);
 e.balanceTimer=Math.max(0,e.balanceTimer-dt);if(e.balanceTimer<=0)e.balance=Math.min(e.maxBalance,e.balance+profile().balanceRegen*.64*dt);
 e.knockX*=Math.exp(-dt*13);e.knockZ*=Math.exp(-dt*13);
 e.x=clamp(e.x+e.knockX*dt,-6.65,6.65);e.z=clamp(e.z+e.knockZ*dt,-6.65,6.65);
 if(e.air>0){e.airVel-=13*dt;e.air=Math.max(0,e.air+e.airVel*dt);if(e.air===0){e.downTimer=.70;e.downTotal=.70;e.phase='down';}}
 if(e.downTimer>0){e.downTimer=Math.max(0,e.downTimer-dt);if(e.downTimer===0){e.getup=.4;e.phase='getup';}}
 if(e.getup>0){e.getup=Math.max(0,e.getup-dt);if(e.getup===0){e.phase='chase';e.cooldown=.8;}}
 if(e.air>0||e.downTimer>0||e.getup>0)return;
 if(e.stun>0){e.stun=Math.max(0,e.stun-dt);e.phase='stun';e.bossQueue=[];if(e.stun===0){e.phase='recover';e.recover=.60;}return;}
 if(player.hp<=0)return;
 const nextStage=e.hp/e.maxHp<=.30?3:e.hp/e.maxHp<=.65?2:1;
 if(nextStage>e.bossStage){e.bossStage=nextStage;e.bossQueue=[];e.phase='recover';e.recover=1.12;e.bossWeak=.65;e.bossPhaseFlash=1.2;e.wind=0;e.strike=0;e.cooldown=.8;
  ring(e.x,e.z,'#ffbe72',42,1.4);burst(e.x,e.z,'#ffd99c',26,1.3);note('FASE '+(nextStage===2?'II · RUPTURA':'III · ECLIPSE'),'Novo padrão de ataques. Observe os avisos!',1.7);}
 const dx=player.x-e.x,dz=player.z-e.z,dist=length(dx,dz),to=unit(dx,dz);
 e.moveMagnitude=mix(e.moveMagnitude||0,(e.phase==='chase'||e.phase==='strike'&&e.type==='dash')?1:0,1-Math.exp(-dt*10));
 if(e.phase==='windup'){
  e.wind-=dt;
  if(e.wind<=0){e.phase='strike';e.strike=e.type==='dash'?.40:e.type==='crush'?.38:e.type==='thrust'?.32:.33;e.strikeMax=e.strike;e.hit=false;
   swipe(e.x,e.z,'enemy',e.face,e.type==='crush'?-1:1,e.type==='crush'?1.4:1.05,{color:e.type==='crush'?'#ff484c':'#ffcf86',edge:'#fff1cd'});}
  return;
 }
 if(e.phase==='strike'){
  e.strike=Math.max(0,e.strike-dt);
  if(e.type==='dash'){const oldX=e.x,oldZ=e.z;e.x=clamp(e.x+e.face.x*6.45*dt,-6.65,6.65);e.z=clamp(e.z+e.face.z*6.45*dt,-6.65,6.65);e.walk+=dt*17;if(!e.hit&&distanceToSegment(player.x,player.z,oldX,oldZ,e.x,e.z)<.87){e.hit=true;enemyDamage();}}
  if(!e.hit&&e.strike<=e.strikeMax*.50&&e.type!=='dash'){e.hit=true;
   const closeEnough=length(player.x-e.x,player.z-e.z)<(e.type==='thrust'?2.55:e.type==='crush'?2.05:e.type==='dash'?1.7:2.1);
   const facing=unit(player.x-e.x,player.z-e.z);
   if(closeEnough && facing.x*e.face.x+facing.z*e.face.z>(e.type==='thrust'?.68:e.type==='crush'?.22:.25))enemyDamage();
   else if(e.type==='crush'||e.type==='dash'){e.bossWeak=Math.max(e.bossWeak,1.45);floating('ABERTURA!',e.x,e.z,'#baffd9',15);}
  }
  if(e.strike<=0){
   if(e.type==='dash'&&!e.hit){e.bossWeak=Math.max(e.bossWeak,1.45);floating('INVESTIDA FALHOU · ABERTURA!',e.x,e.z,'#baffd9',13);}
   if(e.bossQueue?.length){const next=e.bossQueue.shift();eliteBegin(e,next,true);}
   else {e.phase='recover';e.recover=(e.type==='crush'?.95:e.type==='dash'?.77:.52)*profile().recovery;if(e.type==='crush')e.bossWeak=Math.max(e.bossWeak,1.06);}
  }return;
 }
 if(e.phase==='recover'){e.recover=Math.max(0,e.recover-dt);if(e.recover===0){e.phase='chase';e.cooldown=(e.bossStage===3?.37:e.bossStage===2?.50:.64)*profile().cooldown;}return;}
 e.phase='chase';e.cooldown=Math.max(0,e.cooldown-dt);e.face=to;
 const desired=2.05;
 if(dist>desired){const speed=e.aiSpeed*(e.bossStage===3?1.19:e.bossStage===2?1.07:1);
  e.x=clamp(e.x+to.x*speed*dt,-6.65,6.65);e.z=clamp(e.z+to.z*speed*dt,-6.65,6.65);e.walk+=dt*12;}
 else if(dist<1.05){e.x=clamp(e.x-to.x*.8*dt,-6.65,6.65);e.z=clamp(e.z-to.z*.8*dt,-6.65,6.65);e.walk+=dt*8;}
 if(e.cooldown>0||e.bossWeak>.2||dist>4.6)return;
 const patterns=e.bossStage===1?['slash','thrust','slash','double']:
 e.bossStage===2?['thrust','double','crush','slash','dash']:
 ['double','crush','dash','thrust','crush','slash'];
 let type=patterns[e.bossCycle%patterns.length];e.bossCycle++;
 if(e.bossAdapt>0){type=e.bossStage>=2?(dist>2.35?'dash':'crush'):'thrust';e.bossAdapt=0;label('SENTINELA ANTECIPA SUA REPETIÇÃO! Observe o aviso.',1.2);}
 else if(e.bossStage>=2&&dist>3.25&&e.bossCycle%3===0)type='dash';
 if(type==='double'){e.bossQueue=['slash'];eliteBegin(e,'slash');}
 else eliteBegin(e,type);
}
function enemyBrain(dt){
 if(!enemy||enemy.hp<=0)return;if(enemy.style==='elite')return eliteBrain(dt);
 const e=enemy,p=FOES[e.choice];e.moveMagnitude=mix(e.moveMagnitude||0,(e.phase==='chase'||e.phase==='evade'||e.phase==='strike'&&e.type==='rush')?.8:0,1-Math.exp(-dt*10));
 e.reaction=Math.max(0,(e.reaction||0)-dt);e.flash=Math.max(0,e.flash-dt);e.iframe=Math.max(0,e.iframe-dt);
 e.guardCooldown=Math.max(0,e.guardCooldown-dt);e.evadeCooldown=Math.max(0,e.evadeCooldown-dt);
 e.balanceTimer=Math.max(0,e.balanceTimer-dt);
 if(e.balanceTimer<=0)e.balance=Math.min(e.maxBalance,e.balance+profile().balanceRegen*dt);
 e.knockX*=Math.exp(-dt*10);e.knockZ*=Math.exp(-dt*10);
 e.coverCooldown=Math.max(0,(e.coverCooldown||0)-dt);
 e.flankCooldown=Math.max(0,(e.flankCooldown||0)-dt);
 e.flankComplete=Math.max(0,(e.flankComplete||0)-dt);
 e.allyDownReaction=Math.max(0,(e.allyDownReaction||0)-dt);
 e.tacticPulse=Math.max(0,(e.tacticPulse||0)-dt);e.attackReady=Math.max(0,(e.attackReady||0)-dt);
 e.guardCounter=Math.max(0,(e.guardCounter||0)-dt);

 e.x=clamp(e.x+e.knockX*dt,-6.65,6.65);e.z=clamp(e.z+e.knockZ*dt,-6.65,6.65);
 if(e.air>0){e.airVel-=13*dt;e.air=Math.max(0,e.air+e.airVel*dt);
  if(e.air===0){e.airVel=0;e.downTimer=Math.max(e.downTimer,.71);e.downTotal=Math.max(e.downTotal,.71);e.phase='down';ring(e.x,e.z,'#ffda7f',20,.8);}}
 if(e.downTimer>0&&e.air===0){e.downTimer=Math.max(0,e.downTimer-dt);if(e.downTimer===0){e.getup=.36;e.phase='getup';e.cooldown=Math.max(e.cooldown,.70);}}
 if(e.getup>0){e.getup=Math.max(0,e.getup-dt);if(e.getup===0)e.phase='chase';}
 if(e.air>0||e.downTimer>0||e.getup>0){e.wind=0;e.strike=0;return;}
 if(e.stun>0){e.stun=Math.max(0,e.stun-dt);e.phase='stun';if(!e.stun){e.phase='chase';e.cooldown=Math.max(e.cooldown,.65);}return;}
 if(player.hp<=0)return;
 const dx=player.x-e.x,dz=player.z-e.z,dist=length(dx,dz),to=unit(dx,dz);
 if(e.phase==='guard'){
  e.guardTime-=dt;e.face=to;
  if(e.guardTime<=0){e.phase='chase';e.guardAlly=null;e.cooldown=Math.max(e.cooldown,.24);
   if(tacticalOn()&&e.guardCounter>0&&length(player.x-e.x,player.z-e.z)<1.92){e.guardCounter=0;beginEnemyWindup('light');}
  }
  return;
 }
 if(e.phase==='evade'){
  e.evade=Math.max(0,e.evade-dt);const side={x:-to.z*e.side,z:to.x*e.side};
  e.x=clamp(e.x+side.x*4.6*dt-to.x*1.1*dt,-6.65,6.65);e.z=clamp(e.z+side.z*4.6*dt-to.z*1.1*dt,-6.65,6.65);
  e.walk+=dt*18;e.face=to;if(e.evade===0){e.phase='chase';e.cooldown=Math.max(e.cooldown,.33);}return;
 }
 if(e.phase==='feint'){
  e.feintCount-=dt;e.face=to;
  if(e.feintCount<=0){e.side*=-1;const side={x:-to.z*e.side,z:to.x*e.side};e.x=clamp(e.x+side.x*.48,-6.65,6.65);e.z=clamp(e.z+side.z*.48,-6.65,6.65);beginEnemyWindup('quick');}
  return;
 }
 if(e.phase==='windup'){
  e.wind-=dt;
  if(e.wind<=0){e.phase='strike';e.strike=e.type==='rush'?.42:e.type==='heavy'?.40:.30;e.strikeMax=e.strike;e.hit=false;
   swipe(e.x,e.z,'enemy',e.face,-1,e.type==='heavy'?1.18:.88);}
  return;
 }
 if(e.phase==='strike'){
  e.strike=Math.max(0,e.strike-dt);
  if(e.type==='rush'){
   e.x=clamp(e.x+e.face.x*6.1*dt,-6.65,6.65);e.z=clamp(e.z+e.face.z*6.1*dt,-6.65,6.65);e.walk+=dt*18;
  }
  const impactTime=e.type==='rush'?.36:e.type==='heavy'?.25:.17;
  if(!e.hit&&e.strike<=impactTime){
   if(e.type==='rush'){
    const d=length(player.x-e.x,player.z-e.z);
    if(d<=1.53){e.hit=true;enemyDamage();}
   }else{e.hit=true;enemyDamage();}
  }
  if(e.strike<=0){e.phase='recover';e.recover=(e.type==='heavy'?.57:e.type==='rush'?.64:.39)*profile().recovery;}
  return;
 }
 if(e.phase==='recover'){
  e.recover=Math.max(0,e.recover-dt);
  if(e.recover===0){e.phase='chase';e.cooldown=(e.style==='berserker'?.46:e.style==='duelist'?.68:1.0)*profile().cooldown;}
  return;
 }
 e.phase='chase';e.cooldown=Math.max(0,e.cooldown-dt);
 e.face=to;if(drill.active&&drill.behavior==='dummy')return;
 const canObservePlayer=dist<3.3;
 const preparingHeavy=canObservePlayer&&player.act&&!player.act.hit&&player.act.key.includes('H')&&player.act.time<player.act.move.dur*.58;

 if(!drill.active&&e.style==='duelist'&&e.evadeCooldown<=0&&preparingHeavy&&dist<2.6&&dist>.60){
   e.phase='evade';e.evade=.27;e.iframe=.23;e.evadeCooldown=3.10;e.side*=-1;
   floating('ESQUIVA!',e.x,e.z,'#d9b1ff',13);ring(e.x,e.z,'#ac8aff',13,.60);return;
 }
 if(!drill.active&&e.style==='guardian'&&e.guardCooldown<=0&&player.act&&!player.act.hit&&dist<2.85){
  const localAllies=tacticalOn()?living().filter(a=>a!==e&&length(a.x-e.x,a.z-e.z)<2.3&&length(a.x-player.x,a.z-player.z)<2.65):[];
  const ally=localAllies.sort((a,b)=>length(a.x-player.x,a.z-player.z)-length(b.x-player.x,b.z-player.z))[0];
  const threatened=!!ally&&unit(ally.x-player.x,ally.z-player.z).x*player.face.x+unit(ally.x-player.x,ally.z-player.z).z*player.face.z>.39;
  e.phase='guard';e.guardTime=threatened?1.03:.82;e.guardCooldown=threatened?3.15:2.85;
  e.guardAlly=threatened?ally.id:null;e.guardCounter=1.35;
  if(threatened){floating('PROTEGENDO ALIADO',e.x,e.z,'#8affdf',13);label('GUARDIÃO COBRE UM ALIADO — quebre sua postura',1.05);}
  else label('ESCUDO LEVANTADO: golpeie a postura',.75);
  return;
 }
 const preferred=e.preferred;
 if(tacticalOn()&&e.role==='flanco'&&e.flankCooldown<=0&&e.allyDownReaction<=0){
  // Positions are relative to the visible player posture. Deliberately limited speed and radius.
  const behind=rotate(player.face,e.flankSide*2.12);
  const goal={x:clamp(player.x+behind.x*2.0,-6.2,6.2),z:clamp(player.z+behind.z*2.0,-6.2,6.2)};
  const dGoal=length(goal.x-e.x,goal.z-e.z),approach=unit(goal.x-e.x,goal.z-e.z);
  if(dGoal>.68&&dist<4.7){
   const speed=e.aiSpeed*.88;
   e.x=clamp(e.x+approach.x*speed*dt,-6.65,6.65);e.z=clamp(e.z+approach.z*speed*dt,-6.65,6.65);e.walk+=dt*12;
   if(e.cooldown<=0)e.cooldown=Math.max(e.cooldown,.12);
   return;
  }
  if(dGoal<=.68){e.flankComplete=.75;e.flankCooldown=3.35;totalFlanks++;e.tacticPulse=.8;
   floating('FLANCO!',e.x,e.z,'#d7b9ff',13);
   if(clock-lastTacticBanner>1.5){label('CERCO LATERAL! Esquive ou faça parry',1.15);lastTacticBanner=clock;}
  }
 }
 if(dist>preferred){
  const pace=e.style==='berserker'&&e.hp<e.maxHp*.50?e.aiSpeed*1.17:e.aiSpeed;
  let sideSpeed=0;
  if(e.style==='duelist'&&dist<3.35)sideSpeed=.77*e.side;
  if(squadSize>1&&dist<4.0&&!tacticalOn())sideSpeed+=((e.slot%2)?1:-1)*.44;
  if(tacticalOn()&&e.role==='pressão'&&dist<3.55)sideSpeed=.55*(e.slot%2?-1:1);
  e.x=clamp(e.x+(to.x*pace-to.z*sideSpeed)*dt,-6.65,6.65);
  e.z=clamp(e.z+(to.z*pace+to.x*sideSpeed)*dt,-6.65,6.65);e.walk+=dt*12;
 }else if(e.style==='duelist'&&dist<1.30){
  e.x=clamp(e.x-to.x*.9*dt,-6.65,6.65);e.z=clamp(e.z-to.z*.9*dt,-6.65,6.65);e.walk+=dt*8;
 }
 if(e.allyDownReaction>0&&tacticalOn())return;
 if(drill.active&&drill.behavior==='pursue')return;
 if(e.cooldown>0)return;
 if(drill.active){if(dist<=2.08)beginEnemyWindup(drill.behavior==='mixed'?(++drill.attacks%2?'light':'heavy'):drill.behavior);return;}
 // A visible missed heavy swing offers a telegraphed, punishable counter, not an instant hit.
 if(tacticalOn()&&player.act&&!player.act.landed&&player.act.key.includes('H')&&player.act.time>player.act.move.dur*.68&&dist<2.0&&e.style==='duelist'&&e.attackReady<=0){
  e.attackReady=.9;floating('CONTRA-ATAQUE!',e.x,e.z,'#f7b9e5',13);
  const oldPhase=e.phase;beginEnemyWindup('quick');if(e.phase==='windup'&&oldPhase!=='windup')totalPunishes++;return;
 }
 // Each style has a recognizable pattern. Decisions are deterministic and give a clear reaction window.
 if(e.style==='berserker'&&dist>2.10&&dist<4.60){beginEnemyWindup('rush');return;}
 if(dist>2.08)return;
 if(e.style==='guardian')beginEnemyWindup(e.attackCount%3===1?'heavy':'light');
 else if(e.style==='duelist'){
  if(e.attackCount%4===2){if(enemies.filter(o=>o.hp>0&&o.id!==e.id&&['windup','strike','feint'].includes(o.phase)).length>=2){e.cooldown=.28;return;}e.phase='feint';e.feintCount=.55;floating('FINTA',e.x,e.z,'#d3baff',13);e.cooldown=.0;}
  else beginEnemyWindup(e.attackCount%3===1?'heavy':'quick');
 }else beginEnemyWindup(e.attackCount%3===1?'heavy':'quick');
}
