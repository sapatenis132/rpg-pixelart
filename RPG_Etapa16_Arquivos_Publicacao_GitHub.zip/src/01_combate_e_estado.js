

(()=>{'use strict';
const $=id=>document.getElementById(id), canvas=$('scene'),ctx=canvas.getContext('2d',{alpha:false}),game=$('game');
const hpFill=$('hpFill'),mpFill=$('mpFill'),hpText=$('hpText'),mpText=$('mpText'),comboUI=$('combo'),hintUI=$('hint'),banner=$('banner'),parryBtn=$('parry'),dodgeBtn=$('dodge'),joy=$('joystick'),stick=$('stick'),guide=$('guide');
const PI=Math.PI,TAU=PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),length=(x,z)=>Math.hypot(x,z),unit=(x,z)=>{let l=Math.hypot(x,z)||1;return{x:x/l,z:z/l}},mix=(a,b,t)=>a+(b-a)*t;
let w=0,h=0,dpr=1,sx=37,sy=19,baseSx=37,clock=0,last=0,shake=0,hitStop=0,kills=0,respawn=0,bannerTime=0,noticeTime=0,screenFlash=0;
let cam={x:0,z:0},player,enemy,particles=[],texts=[],arcs=[],rings=[],flashes=[],specials=[],input={x:0,y:0},keys=new Set(),joyId=null,aimAssist=true,joyCapture=null;
const ATTACKS={
 L:{name:'Corte rápido',dmg:10,dur:.30,impact:.39,reach:1.92,knock:.36,stun:.16,angle:1},
 LL:{name:'Corte cruzado',dmg:13,dur:.33,impact:.40,reach:1.95,knock:.52,stun:.22,angle:-1},
 LLL:{name:'Turbilhão',dmg:24,dur:.47,impact:.43,reach:2.15,knock:.55,stun:.38,angle:1,fin:true,vortex:true},
 LH:{name:'Ruptura',dmg:25,dur:.61,impact:.51,reach:2.18,knock:1.16,stun:.42,angle:-1},
 LLH:{name:'IMPACTO CRESCENTE',dmg:39,dur:.68,impact:.48,reach:2.35,knock:.9,stun:.68,angle:-1,fin:true,launch:true},
 LHL:{name:'CONTRA-CORTE',dmg:28,dur:.37,impact:.40,reach:2.1,knock:1.05,stun:.40,angle:1,fin:true,break:true},
 LHH:{name:'MARTELO DUPLO',dmg:42,dur:.70,impact:.55,reach:2.3,knock:1.0,stun:.62,angle:1,fin:true,down:true},
 H:{name:'Golpe pesado',dmg:21,dur:.67,impact:.53,reach:2.15,knock:1.28,stun:.43,angle:1},
 HL:{name:'Corte de retorno',dmg:16,dur:.30,impact:.42,reach:1.98,knock:.45,stun:.20,angle:-1},
 HLL:{name:'RAJADA',dmg:30,dur:.43,impact:.40,reach:2.12,knock:1.12,stun:.41,angle:1,fin:true,break:true},
 HLH:{name:'EXECUÇÃO',dmg:45,dur:.73,impact:.52,reach:2.4,knock:2.0,stun:.73,angle:-1,fin:true,execute:true,down:true},
 HH:{name:'GOLPE DUPLO',dmg:32,dur:.77,impact:.53,reach:2.28,knock:.9,stun:.57,angle:-1,fin:true,down:true},
 RIP_L:{name:'RIPOSTA VELOZ',dmg:31,dur:.32,impact:.33,reach:2.45,knock:1.1,stun:.45,angle:-1,fin:true,rip:true},
 RIP_H:{name:'RIPOSTA ESMAGADORA',dmg:52,dur:.62,impact:.45,reach:2.55,knock:1.8,stun:.90,angle:1,fin:true,rip:true,down:true},
 // Four-hit extensions only unlock when the previous finisher ACTUALLY connects.
 LLLH:{name:'QUEDA CIRCULAR',dmg:43,dur:.66,impact:.49,reach:2.35,knock:1.2,stun:.69,angle:-1,fin:true,ext:true,down:true},
 LLHL:{name:'CORTE AÉREO',dmg:30,dur:.39,impact:.40,reach:2.58,knock:.65,stun:.49,angle:1,fin:true,ext:true,airBonus:true,slam:true},
 LHLH:{name:'RUPTURA CRUZADA',dmg:41,dur:.62,impact:.47,reach:2.30,knock:1.1,stun:.62,angle:-1,fin:true,ext:true,break:true},
 LHHL:{name:'RETORNO DE MARTELO',dmg:32,dur:.41,impact:.40,reach:2.20,knock:.65,stun:.47,angle:1,fin:true,ext:true,slam:true},
 HLLH:{name:'ARREMATE DE IMPULSO',dmg:40,dur:.58,impact:.46,reach:2.45,knock:.85,stun:.60,angle:-1,fin:true,ext:true,launch:true},
 HLHL:{name:'CORTE DO JULGAMENTO',dmg:35,dur:.39,impact:.36,reach:2.5,knock:1.1,stun:.48,angle:1,fin:true,ext:true,execute:true},
 HHL:{name:'VARREDURA',dmg:29,dur:.40,impact:.43,reach:2.25,knock:.95,stun:.49,angle:-1,fin:true,ext:true,down:true},
 DASH_L:{name:'PASSO CORTANTE',dmg:16,dur:.30,impact:.38,reach:2.38,knock:.45,stun:.22,angle:1,dash:true},
 DASH_H:{name:'INVESTIDA',dmg:31,dur:.50,impact:.45,reach:2.55,knock:1.0,stun:.50,angle:-1,dash:true,down:true}
};
const BALANCE={
 training:{name:'TREINO',enemyHp:.84,enemyDamage:.70,windup:1.26,cooldown:1.28,recovery:1.16,parry:.30,dodgeIframes:.27,tempo:.71,minWind:.64,postHitIframes:.68,balanceRegen:12},
 balanced:{name:'EQUILIBRADO',enemyHp:.93,enemyDamage:.90,windup:1.09,cooldown:1.15,recovery:1.10,parry:.25,dodgeIframes:.24,tempo:.50,minWind:.56,postHitIframes:.60,balanceRegen:16},
 challenge:{name:'DESAFIO',enemyHp:1.07,enemyDamage:1.16,windup:.94,cooldown:.91,recovery:.96,parry:.21,dodgeIframes:.20,tempo:.34,minWind:.51,postHitIframes:.55,balanceRegen:20}
};
function profile(){return BALANCE[settings.difficulty]||BALANCE.balanced;}
let parryAttempts=0,parryMisses=0,dodgeSaves=0,totalSwings=0,successfulSwings=0,maxChain=0,damageTimeline=[],waveStart=0,waveStartDamage=0,waveStartTaken=0,waveStartParries=0,waveStartSwings=0,waveStartSuccess=0,lastWave=null,attackBegins=0;
function trainingAccuracy(){return totalSwings?Math.round(successfulSwings/totalSwings*100):0;}
function dps(){const recent=damageTimeline.filter(e=>clock-e.t<=10);return recent.length?Math.round(recent.reduce((sum,e)=>sum+e.d,0)/Math.min(10,Math.max(1,clock))):0;}
function waveFinished(){const duration=Math.max(.1,clock-waveStart);const dealt=totalDamage-waveStartDamage,taken=totalTaken-waveStartTaken;const shots=totalSwings-waveStartSwings,success=successfulSwings-waveStartSuccess,accuracy=shots?Math.round(100*success/shots):0;
 const grade=taken<=8&&duration<55?'A':taken<=24?'B':taken<=53?'C':'D';
 const advice=taken>35?'Você recebeu muito dano. Priorize distância e sinais dos golpes.':accuracy<48?'Poucos cortes conectaram. Use a mira assistida e controle o alcance.':totalParries-waveStartParries===0?'Experimente usar parry nos avisos de ataque.':'Boa leitura do combate. Compare este resultado em outra dificuldade.';
 lastWave={duration:duration.toFixed(1),dealt,taken,parries:totalParries-waveStartParries,grade,advice,accuracy};
 updateTrainingReadout();
}
function updateTrainingReadout(){const b=document.getElementById('trainingHud');if(!b)return;
 b.textContent=`Precisão ${trainingAccuracy()}% · ${dps()} dano/s · Parry ${totalParries}/${parryAttempts} · Esquivas ${dodgeSaves}`;
 const report=document.getElementById('waveReport');if(report)report.textContent=lastWave?`ÚLTIMA ONDA · NÍVEL ${lastWave.grade} · ${lastWave.duration}s · Dano ${lastWave.dealt} · Sofrido ${lastWave.taken} · Precisão ${lastWave.accuracy}% · Parries ${lastWave.parries} · ${lastWave.advice}`:'Complete uma onda para receber uma análise de desempenho.';
}
function updateDifficultyUI(){const data=profile();const b=document.getElementById('difficultyBtn');if(!b)return;
 b.textContent='⚖ '+data.name+' ↻';
 for(const el of document.querySelectorAll('#difficultyChoices button')){const on=el.dataset.mode===settings.difficulty;el.classList.toggle('selected',on);el.setAttribute('aria-pressed',String(on));}
 const detail=document.getElementById('balanceInfo');if(detail)detail.textContent=`${data.name} · Dano inimigo ${Math.round(data.enemyDamage*100)}% · Vida inimiga ${Math.round(data.enemyHp*100)}% · Preparo ${Math.round(data.windup*100)}% · Parry ${Math.round(data.parry*1000)} ms. Os ataques continuam sinalizados e a mana não é gasta.`;
}
function setDifficulty(mode){if(!BALANCE[mode]||mode===settings.difficulty)return;
 settings.difficulty=mode;saveSettings();reset();updateDifficultyUI();note('MODO '+profile().name,'Treino reiniciado para comparação justa',1.7);
}
function cycleDifficulty(){const modes=['training','balanced','challenge'];setDifficulty(modes[(modes.indexOf(settings.difficulty)+1)%modes.length]);}
const FOES=[
 {id:'guardian',name:'GUARDIÃO',title:'GUARDIÃO DE FERRO',life:285,balance:112,speed:1.36,reach:1.80,color:'#7bd9d2',hint:'Defende com escudo • pressione a postura'},
 {id:'duelist',name:'DUELISTA',title:'DUELISTA VIOLETA',life:210,balance:76,speed:2.10,reach:1.69,color:'#c9a3ff',hint:'Movimento lateral • fintas e esquivas'},
 {id:'berserker',name:'FURIOSO',title:'FURIOSO RUBRO',life:250,balance:87,speed:2.15,reach:1.55,color:'#ff9a75',hint:'Investidas • ataques em sequência'},
 {id:'elite',name:'SENTINELA',title:'SENTINELA DO ECLIPSE',life:660,balance:160,speed:2.06,reach:2.15,color:'#ffcb8b',hint:'Três fases • postura • golpes inaparaveis'}
];
let selectedEnemy=0, squadSize=3, enemies=[], focusId=null, nextEnemyId=0, wavesCleared=0, eliteMode=false, eliteVictory=false;
// A separate practice loop lives on top of the full combat engine; normal arenas remain untouched.
const DRILLS={
 parry:{title:'PARRY PERFEITO',target:3,tip:'Aperte PARRY pouco antes do contato do golpe inimigo.',description:'Consiga três parries perfeitos. Observe o aviso de ataque, escute o golpe e aperte PARRY no instante de contato.',behavior:'light'},
 dodge:{title:'ESQUIVA NO IMPACTO',target:3,tip:'Esquive na hora do contato, não durante todo o preparo.',description:'Evite três golpes com os quadros de invulnerabilidade da esquiva. Mantenha-se próximo para que o inimigo alcance sua posição.',behavior:'heavy'},
 combo:{title:'CORTE AÉREO',target:2,tip:'LEVE → LEVE → PESADO → LEVE, acertando o finalizador.',description:'Acerte duas vezes a sequência L → L → P → L, com lançamento e Corte Aéreo. A extensão só funciona se o Impacto Crescente atingir.',behavior:'dummy'},
 finish:{title:'MESTRE DOS FINALIZADORES',target:3,tip:'Acerte três finalizadores DIFERENTES.',description:'Acerte três tipos diferentes de finalizadores. Exemplos: LLL, LLH, LHL, HLH. Repetir o mesmo finalizador não aumenta a pontuação.',behavior:'dummy'},
 sandbox:{title:'TREINO LIVRE',target:0,tip:'Experimente combos, parry, esquiva e alcance.',description:'Sem metas: configure o inimigo para ficar parado, perseguir ou repetir ataques. O inimigo reaparece automaticamente sem interromper sua prática.',behavior:'dummy'}
};
let drill={active:false,mode:'parry',foe:0,behavior:'light',score:0,errors:0,start:0,done:false,unique:new Set(),last:'Pronto para treinar',attacks:0};
function drillTarget(){return DRILLS[drill.mode];}
function drillRefresh(){const data=drillTarget(),elapsed=drill.active?Math.max(0,clock-drill.start):0;
 $('labScore').textContent=data.target?`${drill.score}/${data.target}`:'LIVRE';$('labErrors').textContent=drill.errors;$('labTime').textContent=Math.floor(elapsed)+'s';
 $('drillTitle').textContent=drill.done?'✓ EXERCÍCIO CONCLUÍDO':data.title+' · '+(data.target?drill.score+'/'+data.target:'LIVRE');
 $('drillTip').textContent=data.tip;$('drillMeterFill').style.width=(data.target?Math.min(100,100*drill.score/data.target):0)+'%';
 $('drillFeedback').textContent=drill.last;$('labBtn').classList.toggle('active',drill.active);$('labBtn').textContent=drill.active?'✦ TREINANDO':'✦ TREINO';
 $('labDescription').textContent=DRILLS[$('drillPanel').classList.contains('open')?$('drillMode').value:drill.mode].description+(drill.active?`  ·  Atual: ${drill.last}`:'');}
function drillSuccess(label){if(!drill.active||drill.done)return;drill.score++;drill.last=label;floating('TREINO +1',player.x,player.z,'#b8ffce',15);if(drill.score>=drillTarget().target){drill.done=true;drill.last='OBJETIVO CONCLUÍDO! Você pode repetir ou continuar treinando.';note('EXERCÍCIO CONCLUÍDO!','Abra ✦ TREINANDO para repetir ou mudar a missão',2.2);sfx('parry');}drillRefresh();}
function drillFailure(label){if(!drill.active||drill.done)return;drill.errors++;drill.last=label;drillRefresh();}
function drillEvent(event,key){if(!drill.active||drill.done)return;
 if(drill.mode==='parry'&&event==='parry')drillSuccess('Parry perfeito! '+(drill.score+1)+' de 3');
 else if(drill.mode==='dodge'&&event==='dodge')drillSuccess('Esquiva no contato! '+(drill.score+1)+' de 3');
 else if(drill.mode==='combo'&&event==='landed'&&key==='LLHL')drillSuccess('Corte Aéreo conectado!');
 else if(drill.mode==='finish'&&event==='landed'&&ATTACKS[key]?.fin&&!drill.unique.has(key)){drill.unique.add(key);drillSuccess('Novo finalizador: '+ATTACKS[key].name);}
}
function labSetMode(mode){if(!DRILLS[mode])return;$('drillMode').value=mode;$('drillBehavior').value=DRILLS[mode].behavior;$('labDescription').textContent=DRILLS[mode].description;}
function openLab(){keys.clear();joyReset();guide.classList.remove('open');options.classList.remove('open');$('drillMode').value=drill.mode;$('drillFoe').value=drill.foe;$('drillBehavior').value=drill.behavior;$('drillPanel').classList.add('open');drillRefresh();frameAccumulator=0;}
function closeLab(){$('drillPanel').classList.remove('open');last=0;frameAccumulator=0;}
function startLab(){eliteMode=false;eliteVictory=false;game.classList.remove('in-elite');drill.active=true;drill.mode=$('drillMode').value;drill.behavior=$('drillBehavior').value;drill.foe=clamp(Number($('drillFoe').value),0,2);squadSize=1;selectedEnemy=drill.foe;
 reset();game.classList.add('in-drill');closeLab();note('TREINO: '+drillTarget().title,'Use ⌖ para reposicionar o parceiro',1.8);drillRefresh();}
function exitLab(){eliteMode=false;eliteVictory=false;game.classList.remove('in-elite');drill.active=false;game.classList.remove('in-drill');squadSize=3;reset();closeLab();label('Arena normal restaurada: trio de inimigos',1.6);drillRefresh();}
function repositionLab(){if(!drill.active)return;const e=enemies[0];if(!e)return;
 e.x=clamp(player.x+player.face.x*1.85,-6.5,6.5);e.z=clamp(player.z+player.face.z*1.85,-6.5,6.5);e.face=unit(player.x-e.x,player.z-e.z);e.phase='chase';e.wind=0;e.strike=0;e.recover=0;e.knockX=e.knockZ=0;e.stun=0;e.air=e.airVel=e.downTimer=e.getup=0;e.cooldown=.75;e.hp=e.maxHp;
 player.act=null;player.buffer=null;player.seq='';player.chainReady=false;player.seqTimer=0;label('Parceiro reposicionado · pronto para treinar',1.2);}

let lastAttackOrdered=-10, totalFlanks=0,totalCovers=0,totalPunishes=0,peakAttackers=0,lastTacticBanner=-10;
