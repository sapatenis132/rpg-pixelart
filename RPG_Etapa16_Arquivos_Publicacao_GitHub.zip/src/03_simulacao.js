function update(dt){clock+=dt;shake*=Math.exp(-dt*14);
 if(bannerTime>0&&bannerTime!==999){bannerTime-=dt;if(bannerTime<=0)banner.classList.remove('visible');}
 if(noticeTime>0){noticeTime-=dt;if(noticeTime<=0)hintUI.textContent='Esquiva direcional · Parry no impacto · ? para combos';}
 for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.z+=p.vz*dt;p.y+=p.vy*dt;p.vy+=130*dt;}particles=particles.filter(p=>p.life>0);
 for(const t of texts){t.life-=dt;t.y+=36*dt;}texts=texts.filter(t=>t.life>0);
 for(const a of arcs)a.life-=dt;arcs=arcs.filter(a=>a.life>0);
 for(const r of rings)r.life-=dt;rings=rings.filter(r=>r.life>0);
 for(const f of flashes)f.life-=dt;flashes=flashes.filter(f=>f.life>0);
 for(const f of specials)f.life-=dt;specials=specials.filter(f=>f.life>0);
 screenFlash=Math.max(0,screenFlash-dt*2.5);
 player.reaction=Math.max(0,(player.reaction||0)-dt);player.flash=Math.max(0,player.flash-dt);player.invuln=Math.max(0,player.invuln-dt);player.seqTimer=Math.max(0,player.seqTimer-dt);if(player.seqTimer===0)player.chainReady=false;player.dodgeFollowup=Math.max(0,player.dodgeFollowup-dt);if(player.dodgeFollowup===0)player.dodgeChain=false;player.riposte=Math.max(0,player.riposte-dt);player.parryCooldown=Math.max(0,player.parryCooldown-dt);player.attackLock=Math.max(0,player.attackLock-dt);
 if(player.buffer){player.bufferTime-=dt;if(player.bufferTime<=0){player.buffer=null;player.bufferTime=0;}}
 const parryBefore=player.parryWindow;player.parryWindow=Math.max(0,player.parryWindow-dt);if(parryBefore>0&&player.parryWindow===0){parryMisses++;if(drill.mode==='parry')drillFailure('Parry antecipado: aguarde mais perto do contato.');}player.parryRecovery=Math.max(0,player.parryRecovery-dt);player.dodgeCooldown=Math.max(0,player.dodgeCooldown-dt);
 if(player.hp>0){
  const v=movement();
  if(player.dodge>0){
   player.dodge=Math.max(0,player.dodge-dt);
   const speed=player.dodge>.09?12:7.2;
   player.x=clamp(player.x+player.dodgeDir.x*speed*dt,-6.65,6.65);
   player.z=clamp(player.z+player.dodgeDir.z*speed*dt,-6.65,6.65);
   player.moveMagnitude=1;player.walk+=dt*27;
   if(player.dodge===0&&player.buffer&&player.bufferTime>0){const type=player.buffer;player.buffer=null;player.bufferTime=0;startAttack(type);}
  }else{
   const speed=3.95*(player.parryRecovery>0?.74:player.act?(player.act.key.includes('H')?.59:.89):1);
   // Fast start, controlled stop: joystick never feels sluggish or slippery.
   const response=length(v.x,v.z)>.01?20:27;
   player.velX=mix(player.velX,v.x*speed,1-Math.exp(-response*dt));
   player.velZ=mix(player.velZ,v.z*speed,1-Math.exp(-response*dt));
   player.x=clamp(player.x+(player.velX+player.knockX)*dt,-6.65,6.65);
   player.z=clamp(player.z+(player.velZ+player.knockZ)*dt,-6.65,6.65);
   player.moveMagnitude=mix(player.moveMagnitude||0,Math.min(1,length(v.x,v.z)),1-Math.exp(-dt*12));if(length(v.x,v.z)>.12)player.walk+=dt*13;
   if(!player.act&&player.parryRecovery<=0){const aim=aimChoice(v);player.assist=aim.locked;if(length(v.x,v.z)>.12||aim.locked)turnToward(aim.dir,17,dt);}

   if(player.act){
    let a=player.act;const oldProgress=a.time/a.move.dur;a.time+=dt;
    const progress=a.time/a.move.dur;
    // Limited steering in the wind-up: generous for light cuts, deliberate for heavy cuts.
    if(!a.hit && progress<Math.min(a.move.impact*.90,.46) && length(v.x,v.z)>.20){
      const aim=aimChoice(v),alignment=player.face.x*aim.dir.x+player.face.z*aim.dir.z;
      if(alignment>-.08){turnToward(aim.dir,a.key.includes('H')?4.6:8.6,dt);player.assist=aim.locked;}
    }

    if(progress>.15&&progress<.55){
     const reach=enemy?.hp>0?length(enemy.x-player.x,enemy.z-player.z):10;
     if(reach>.72){const lunge=(a.move.dash?5.7:a.key.includes('H')?1.30:1.5)*dt;
      player.x=clamp(player.x+player.face.x*lunge,-6.65,6.65);
      player.z=clamp(player.z+player.face.z*lunge,-6.65,6.65);}
    }
    const active=activeInterval(a.move);
    if(progress>=active.start&&oldProgress<=active.end){
      for(const foe of living())if(!a.hitIds.has(foe.id)&&bladeTouch(a,oldProgress,progress,foe))playerHit(true,foe);
    }
    if(progress>=active.end&&!a.finishedArc){
      if(!a.hit)playerHit(false);
      a.finishedArc=true;
    }
    // A hit does not skip recovery. Only one buffered action may follow a completed swing.
    if(player.act===a&&a.time>=a.move.dur){
     player.act=null;
     const buffered=player.bufferTime>0?player.buffer:null;
     player.buffer=null;player.bufferTime=0;
     if(buffered && a.landed&&!a.mashed){startAttack(buffered);}
     else {
      if(!a.landed||a.mashed){player.seq='';player.seqTimer=0;player.chainReady=false;}
      player.attackLock=a.key.includes('H')?.18:.095;
     }
    }
   }
   if(readyForNext()&&player.buffer&&player.bufferTime>0){const type=player.buffer;player.buffer=null;player.bufferTime=0;startAttack(type);}
  }
  player.knockX*=Math.exp(-dt*15);player.knockZ*=Math.exp(-dt*15);
 }
 for(const foe of enemies){enemy=foe;enemyBrain(dt);}
 chooseTarget();
 if(!drill.active&&respawn>0){respawn-=dt;if(respawn<=0){selectedEnemy=(selectedEnemy+1)%3;spawnWave();note('NOVA ONDA','Posicione-se e controle o grupo',1.3);}}
 separateActors();chooseTarget();tacticalReadout();updateEliteUI();
 const active=living(),maxD=active.length?Math.max(...active.map(e=>length(e.x-player.x,e.z-player.z))):0;
 const targetZoom=settings.dynamicCamera?1-clamp((maxD-2.2)*.054,0,.30):1;
 cam.zoom=mix(cam.zoom||1,targetZoom,1-Math.exp(-dt*3));sx=baseSx*cam.zoom;sy=sx*.52;
 // Balanced focus framing: keep close threats in view without pulling camera away from player.
 let avgX=0,avgZ=0,weights=0;
 for(const e of active){const d=length(e.x-player.x,e.z-player.z),weight=1/(1+d*.32);avgX+=e.x*weight;avgZ+=e.z*weight;weights+=weight;}
 avgX=weights?avgX/weights:player.x;avgZ=weights?avgZ/weights:player.z;
 const blend=active.length>1?.24:.19;
 const response=1-Math.exp(-dt*(settings.dynamicCamera?4.6:7.2));
 cam.x=mix(cam.x,mix(player.x,avgX,blend),response);cam.z=mix(cam.z,mix(player.z,avgZ,blend),response);if(Math.floor(clock*8)!==Math.floor((clock-dt)*8))updateFoePicker();if(Math.floor(clock*4)!==Math.floor((clock-dt)*4)){updateTrainingReadout();if(drill.active)drillRefresh();}hud();rhythmReadout();}

