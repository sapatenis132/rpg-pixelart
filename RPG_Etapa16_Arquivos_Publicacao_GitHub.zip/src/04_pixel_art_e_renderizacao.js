function point(x,z){return{x:w*.5+(x-cam.x-z+cam.z)*sx,y:h*.49+(x-cam.x+z-cam.z)*sy};}
function polygon(pts,fill,stroke,width=1){ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.stroke();}}
function line(x1,y1,x2,y2,color,width=2){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();}
const PIXEL_ART = {};
for(const [key,filename] of Object.entries({"hero": "hero_sheet.png", "enemy": "enemy_sheet.png", "guardian": "guardian_sheet.png", "duelist": "duelist_sheet.png", "berserker": "berserker_sheet.png", "elite": "elite_sheet.png", "tile0": "tile_0.png", "tile1": "tile_1.png", "tile2": "tile_2.png", "tile3": "tile_3.png"})){const im=new Image();im.src="assets/"+filename;PIXEL_ART[key]=im;}

function ground(){
  ctx.fillStyle='#07151f';ctx.fillRect(0,0,w,h);
  ctx.imageSmoothingEnabled=false;
  // Cells are true 2:1 isometric diamonds. Draw in world-space painter order.
  const cells=[];
  for(let i=-7;i<7;i++)for(let j=-7;j<7;j++)cells.push({i,j,order:i+j});
  cells.sort((a,b)=>a.order-b.order);
  for(const {i,j} of cells){
    const p=point(i+.5,j+.5);
    const variant=(Math.abs(i*37+j*19+(i*j)*7)%17===0)?3:(Math.abs(i*11+j*23)%9===0)?2:(Math.abs(i*5+j*3)%4===0)?1:0;
    const tex=PIXEL_ART['tile'+variant];
    if(tex?.complete&&tex.naturalWidth){ctx.drawImage(tex,Math.round(p.x-sx),Math.round(p.y-sy),Math.ceil(sx*2),Math.ceil(sy*2));}
    else {polygon([point(i,j),point(i+1,j),point(i+1,j+1),point(i,j+1)],'#253b45','#415f65',1);}
  }
  // Stone pillars / pixels at the perimeter: simple procedural props, no external art.
  for(const [px,pz] of [[-5,-5],[5,5],[5,-5],[-5,5],[-2,5],[4,1]]){
    const p=point(px,pz),s=Math.max(3,Math.round(sx/7));
    ctx.fillStyle='#08151c';ctx.fillRect(Math.round(p.x-2*s),Math.round(p.y-2*s),4*s,2*s);
    ctx.fillStyle='#4a6471';ctx.fillRect(Math.round(p.x-s),Math.round(p.y-5*s),2*s,4*s);
    ctx.fillStyle='#75939b';ctx.fillRect(Math.round(p.x-s),Math.round(p.y-5*s),s,3*s);
    ctx.fillStyle='#263b46';ctx.fillRect(Math.round(p.x),Math.round(p.y-3*s),s,2*s);
    ctx.fillStyle='#b8d19a';ctx.fillRect(Math.round(p.x-s),Math.round(p.y-5*s),2*s,s);
  }
  const v=ctx.createRadialGradient(w*.5,h*.46,h*.12,w*.5,h*.5,Math.max(w,h)*.72);
  v.addColorStop(0,'#0000');v.addColorStop(1,'#03101bbc');ctx.fillStyle=v;ctx.fillRect(0,0,w,h);
}
function ellipse(x,y,rx,ry,fill){ctx.fillStyle=fill;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,TAU);ctx.fill();}
function aimVisual(){
 if(!player||player.hp<=0)return;
 const p=point(player.x,player.z),tip=point(player.x+player.face.x*1.10,player.z+player.face.z*1.10);
 ctx.save();ctx.globalAlpha=.68;ctx.lineWidth=2.1;ctx.strokeStyle=player.assist&&aimAssist?'#79ffe0':'#a9d7ef';ctx.shadowColor=player.assist?'#60ffd1':'#80d3ff';ctx.shadowBlur=9;
 ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(tip.x,tip.y);ctx.stroke();ctx.fillStyle=ctx.strokeStyle;
 const theta=Math.atan2(tip.y-p.y,tip.x-p.x);ctx.beginPath();ctx.moveTo(tip.x+Math.cos(theta)*7,tip.y+Math.sin(theta)*7);ctx.lineTo(tip.x-Math.cos(theta-.55)*7,tip.y-Math.sin(theta-.55)*7);ctx.lineTo(tip.x-Math.cos(theta+.55)*7,tip.y-Math.sin(theta+.55)*7);ctx.closePath();ctx.fill();
 if(enemy&&enemy.hp>0){const d=length(enemy.x-player.x,enemy.z-player.z);const enemyDir=unit(enemy.x-player.x,enemy.z-player.z);const align=enemyDir.x*player.face.x+enemyDir.z*player.face.z;
  if(d<4.2&&align>.4){const q=point(enemy.x,enemy.z);ctx.strokeStyle=aimAssist&&player.assist?'#85f7d7':'#bdd8e5';ctx.lineWidth=2;ctx.setLineDash([7,5]);ctx.globalAlpha=.4+.15*Math.sin(clock*6);ctx.beginPath();ctx.ellipse(q.x,q.y,27,12,0,0,TAU);ctx.stroke();ctx.setLineDash([]);}
 }
 for(const e of living()){const p=point(e.x,e.z);ctx.save();ctx.globalAlpha=e.id===focusId?.8:.19;ctx.strokeStyle=e.id===focusId?'#a5ffe2':'#c9d7e3';ctx.lineWidth=e.id===focusId?2.6:1.3;ctx.setLineDash(e.id===focusId?[]:[5,5]);ctx.beginPath();ctx.ellipse(p.x,p.y,28,13,0,0,TAU);ctx.stroke();ctx.restore();}
 ctx.restore();
}
function figure(u,team){
 if(!u)return;
 const hero=team==='player',alive=u.hp>0;
 const foot=point(u.x,u.z),x=Math.round(foot.x),y=Math.round(foot.y),air=hero?0:(u.air||0);
 const moving=(u.moveMagnitude||0)>.13;
 const animFrame=moving?Math.floor(Math.abs(u.walk||0)*.52)%4:0;
 const heading=Math.atan2(u.face.z,u.face.x);
 const direction=((Math.round(heading/ (TAU/8))%8)+8)%8;
 const img=PIXEL_ART[hero?'hero':u.style]||PIXEL_ART.enemy;
 const atk=hero?u.act:null,attacking=hero?!!atk:u.phase==='strike';
 const progress=hero&&atk?atk.time/atk.move.dur:attacking?1-clamp(u.strike/(u.strikeMax||.3),0,1):0;
 const sw=hero&&atk?swingPose(atk.move,progress):{angle:.0,active:attacking};
 const parrying=hero&&u.parryWindow>0,dodging=hero&&u.dodge>0;
 const stagger=clamp((u.reaction||0)/.30,0,1);
 const s=clamp(sx/36*1.9,1.35,2.7);
 ctx.save();ctx.imageSmoothingEnabled=false;
 // Blocky contact shadow, remains on ground while airborne.
 ctx.globalAlpha=alive?.72:.25;ctx.fillStyle='#01070f';
 ctx.fillRect(x-Math.round(14*s),y-3,Math.round(28*s),6);
 ctx.globalAlpha=1;
 if(air>0){ctx.strokeStyle='#e8a965';ctx.lineWidth=2;ctx.strokeRect(x-18*s,y-7,36*s,14);}
 ctx.translate(x,y-Math.round(air*31));
 let lean=attacking?(progress<.25?-.05:progress<.72?.13:-.025):0;
 lean+=dodging?.09:0;
 lean+=(u.reactionDir||1)*stagger*.08;
 ctx.rotate(lean);
 if(img?.complete&&img.naturalWidth){
   if(!alive)ctx.globalAlpha=.35;
   if(u.flash>0&&Math.floor(clock*22)%2===0)ctx.globalAlpha=.50;
   const bounce=moving?Math.abs(Math.sin(u.walk||0))*2:0;
   ctx.drawImage(img,animFrame*32,direction*48,32,48,Math.round(-16*s),Math.round(-34*s-bounce),Math.round(32*s),Math.round(48*s));
   ctx.globalAlpha=1;
 }else{
  ctx.fillStyle=hero?'#37a7c4':'#b0716c';ctx.fillRect(-13*s,-30*s,26*s,23*s);
  ctx.fillStyle='#e5b88c';ctx.fillRect(-8*s,-42*s,16*s,14*s);
 }
 // Pixel blade: facing follows combat direction; geometric VFX remain unchanged.
 const theta=Math.atan2(point(u.x+u.face.x,u.z+u.face.z).y-y,point(u.x+u.face.x,u.z+u.face.z).x-x);
 const a=theta+(attacking?sw.angle*.7:parrying?-.9:.42),r=attacking?38*s:27*s;
 const x1=Math.round(Math.cos(a)*13*s),y1=Math.round(-21*s+Math.sin(a)*6*s);
 const x2=Math.round(x1+Math.cos(a)*r),y2=Math.round(y1+Math.sin(a)*r*.66);
 ctx.lineCap='square';ctx.lineWidth=Math.max(3,Math.round(s*3));ctx.strokeStyle=hero?'#d5f6fb':'#ffe9cc';
 ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
 ctx.strokeStyle=hero?'#439fb5':'#a75e5e';ctx.lineWidth=Math.max(1,Math.round(s));
 ctx.beginPath();ctx.moveTo(x1+1,y1+1);ctx.lineTo(x2+1,y2+1);ctx.stroke();
 // Enemy distinctions: defensive shield and elite crown/phase aura.
 if(!hero&&u.style==='guardian'){
  const shieldX=Math.round(-15*s),shieldY=Math.round(-25*s);
  ctx.fillStyle=u.phase==='guard'?'#78f5c7':'#4a8b94';
  ctx.fillRect(shieldX,shieldY,Math.round(11*s),Math.round(17*s));
  ctx.fillStyle='#c2fff0';ctx.fillRect(shieldX+Math.round(2*s),shieldY+Math.round(3*s),Math.round(3*s),Math.round(9*s));
 }
 if(!hero&&u.style==='elite'){
  const col=u.bossStage===3?'#ff7268':u.bossStage===2?'#f4c36d':'#e4d4a0';
  ctx.fillStyle=col;ctx.fillRect(Math.round(-9*s),Math.round(-47*s),Math.round(18*s),Math.round(5*s));
  ctx.fillRect(Math.round(-8*s),Math.round(-51*s),Math.round(4*s),Math.round(7*s));
  ctx.fillRect(Math.round(4*s),Math.round(-54*s),Math.round(4*s),Math.round(10*s));
 }
 ctx.restore();
 if(hero){
  if(parrying||u.parryRecovery>0){ctx.strokeStyle=u.parryWindow>0?'#a5ffde':'#62bba3';ctx.lineWidth=3;ctx.strokeRect(x-23*s,y-58*s,46*s,55*s);}
  if(u.riposte>0){ctx.fillStyle='#8cffaa';ctx.fillRect(x-20,y+3,40,3);}
  if(dodging){ctx.strokeStyle='#c2a9ff';ctx.lineWidth=2;ctx.strokeRect(x-21*s,y-14,42*s,19);}
 }else if(alive){
  if(u.phase==='guard'||u.phase==='feint'){ctx.strokeStyle=u.phase==='guard'?'#8affe0':'#dcb3ff';ctx.lineWidth=2;ctx.strokeRect(x-25*s,y-54*s,50*s,51*s);}
  const ww=70,by=y-76*s;
  ctx.fillStyle='#07141e';ctx.fillRect(x-ww/2-2,by-2,ww+4,11);
  ctx.fillStyle='#692c37';ctx.fillRect(x-ww/2,by,ww,6);
  ctx.fillStyle=u.color||'#ff836a';ctx.fillRect(x-ww/2,by,ww*clamp(u.hp/u.maxHp,0,1),6);
  ctx.fillStyle='#203d48';ctx.fillRect(x-ww/2,by+9,ww,3);
  ctx.fillStyle='#f2c86b';ctx.fillRect(x-ww/2,by+9,ww*clamp(u.balance/u.maxBalance,0,1),3);
  ctx.font='bold 10px monospace';ctx.fillStyle='#d7ebef';ctx.textAlign='center';ctx.fillText(u.title||'INIMIGO',x,by-5);
 }
}
function warning(){
 for(const e of enemies){if(e.hp<=0||!['windup','strike','feint'].includes(e.phase))continue;
 const fake=e.phase==='feint',t=fake?1-e.feintCount/.55:e.phase==='windup'?clamp(1-e.wind/e.windMax,0,1):1;
 const p=point(e.x,e.z),next=point(e.x+e.face.x,e.z+e.face.z);
 const theta=Math.atan2(next.y-p.y,next.x-p.x),heavy=e.type==='heavy',rush=e.type==='rush';
 const elite=e.style==='elite',unblockable=elite&&e.type==='crush',eliteDash=elite&&e.type==='dash';
 const col=unblockable?'#ff454f':elite?'#ffd27f':fake?'#c9a5ff':heavy?'#ffcd7e':rush?'#ff734f':'#ff696a';
 ctx.save();ctx.lineWidth=2+t*3;ctx.strokeStyle=col;ctx.globalAlpha=.6+t*.36;
 ctx.beginPath();ctx.ellipse(p.x,p.y,29+t*16,14+t*8,0,0,TAU);ctx.stroke();
 const rad=eliteDash?160:unblockable?110:rush?125:elite&&e.type==='thrust'?135:heavy?90:73,spread=eliteDash?20:unblockable?76:elite&&e.type==='thrust'?20:rush?17:heavy?36:29;
 const cx=p.x+Math.cos(theta)*rad*.56,cy=p.y+Math.sin(theta)*rad*.56;
 ctx.fillStyle=fake?'#ac82ff29':rush?'#ff5d5140':heavy?'#ffb54b2e':'#ff5c512c';
 ctx.beginPath();ctx.moveTo(p.x,p.y);
 ctx.lineTo(cx+Math.cos(theta+Math.PI*.5)*spread,cy+Math.sin(theta+Math.PI*.5)*spread);
 ctx.lineTo(cx-Math.cos(theta+Math.PI*.5)*spread,cy-Math.sin(theta+Math.PI*.5)*spread);ctx.closePath();ctx.fill();
 ctx.lineWidth=2.5;ctx.strokeStyle=col;ctx.stroke();
 const labelText=unblockable?'INAPARÁVEL':eliteDash?'INVESTIDA':elite&&e.type==='thrust'?'ESTOCADA':elite?'CORTE':fake?'FINTA':rush?'INVESTIDA':heavy?'PESADO':'ATAQUE';
 ctx.textAlign='center';ctx.fillStyle=col;ctx.font='1000 11px system-ui';ctx.shadowColor=col;ctx.shadowBlur=10;
 ctx.fillText(labelText,p.x,p.y-110);
 ctx.font='900 26px system-ui';ctx.fillText(unblockable?'✕':fake?'◇':'!',p.x,p.y-83-t*5);
 ctx.restore();
}
}
function traces(){for(const a of arcs){const p=point(a.x,a.z),d=point(a.x+a.face.x,a.z+a.face.z),ang=Math.atan2((d.y-p.y)*1.65,d.x-p.x),q=1-a.life/a.max,r=(a.radius??(a.kind==='rip'?57:a.kind==='heavy'?48:39)),angleStart=ang-1.45*a.angle+q*.7*a.angle,angleEnd=ang+.67*a.angle+q*.8*a.angle,main=a.color??(a.kind==='enemy'?'#ff646a':a.kind==='rip'?'#76ffe3':a.kind==='heavy'?'#ffb875':'#69dafa'),edge=a.edge??'#fff9e9',glow=a.glow??(a.kind==='enemy'?'#ff686e':a.kind==='rip'?'#9fffe2':a.kind==='heavy'?'#ffc16c':'#8ee9ff'),lw=(a.width??(a.kind==='light'?12:17));
 ctx.save();ctx.globalAlpha=Math.pow(1-q,.68);ctx.lineCap='round';ctx.shadowBlur=26;ctx.shadowColor=glow;ctx.lineWidth=lw;ctx.strokeStyle=main;ctx.beginPath();ctx.arc(p.x+Math.cos(ang)*21,p.y-30+Math.sin(ang)*10,r*a.scale,angleStart,angleEnd,a.angle<0);ctx.stroke();
 ctx.lineWidth=Math.max(2,lw*.25);ctx.shadowBlur=0;ctx.strokeStyle=edge;ctx.stroke();
 ctx.globalAlpha*=.28;ctx.fillStyle=main;ctx.beginPath();ctx.moveTo(p.x+Math.cos(angleStart)*(r*.62)+Math.cos(ang)*21,p.y-30+Math.sin(angleStart)*(r*.62)+Math.sin(ang)*10);ctx.arc(p.x+Math.cos(ang)*21,p.y-30+Math.sin(ang)*10,r*.84*a.scale,angleStart,angleEnd,a.angle<0);ctx.closePath();ctx.fill();
 ctx.globalAlpha=Math.pow(1-q,.55);ctx.lineWidth=Math.max(2,lw*.18);ctx.strokeStyle=a.echo??(a.kind==='enemy'?'#ffc3ba':a.kind==='heavy'?'#ffdaaf':'#b3f4ff');ctx.beginPath();ctx.arc(p.x+Math.cos(ang)*18,p.y-31+Math.sin(ang)*10,(r+11)*a.scale,angleStart+.3*a.angle,angleEnd-.3*a.angle,a.angle<0);ctx.stroke();ctx.restore();}}
function specialEffects(){
 for(const fx of specials){
  const p=point(fx.x,fx.z),q=1-fx.life/fx.max,e=Math.min(1,q/.18),fade=Math.pow(1-q,.75),d=point(fx.x+fx.dir.x,fx.z+fx.dir.z),ang=Math.atan2((d.y-p.y)*1.3,d.x-p.x),cx=p.x,cy=p.y-29;
  ctx.save();ctx.translate(cx,cy);ctx.rotate(ang);ctx.globalAlpha=fade*.92;ctx.lineCap='round';ctx.lineJoin='round';
  // 2-color motion strokes with a hard inner blade and soft emissive edge.
  const stroke=(x1,y1,x2,y2,width=5,color=fx.color)=>{ctx.shadowColor=color;ctx.shadowBlur=12;ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.shadowBlur=0;ctx.lineWidth=Math.max(1.5,width*.23);ctx.strokeStyle=fx.edge;ctx.stroke();};
  const pulse=(radius,vertical=.48,width=4,color=fx.color)=>{ctx.strokeStyle=color;ctx.shadowColor=color;ctx.shadowBlur=12;ctx.lineWidth=width;ctx.beginPath();ctx.ellipse(0,28,radius,radius*vertical,0,0,TAU);ctx.stroke();ctx.shadowBlur=0;};
  if(['LLLH','LLHL','LHLH','LHHL','HLLH','HLHL','HHL'].includes(fx.kind)){
   const r=22+q*75;
   for(let i=0;i<3;i++){let a=(i*TAU/3)+q*(fx.kind==='LLLH'?5.5:2.3);stroke(Math.cos(a)*12,Math.sin(a)*10,Math.cos(a)*r,Math.sin(a)*r*.58,9-q*5,i===1?fx.edge:fx.color);}
   if(['LLHL','LHHL','HLHL'].includes(fx.kind))stroke(0,-80+q*70,0,35,11-q*6,fx.edge);
   pulse(15+q*72,.40,5-q*3);
  }else if(fx.kind==='LLL'){
   // Turbilhão: three spiraling passes around the enemy, instead of a giant static slash.
   for(let i=0;i<3;i++){const a=q*6.8+i*TAU/3;ctx.strokeStyle=i===1?fx.edge:fx.color;ctx.lineWidth=6-i;ctx.shadowColor=fx.glow;ctx.shadowBlur=13;ctx.beginPath();ctx.arc(0,2,26+q*26+i*4,a,a+1.55);ctx.stroke();ctx.shadowBlur=0;}
   pulse(25+q*35,.49,2.5);
  }else if(fx.kind==='LLH'){
   // Impacto crescente: an upward energy pillar and a pressure ring on the ground.
   stroke(-9+q*7,39,-7+q*7,-28-91*e,10-q*3);
   stroke(9-q*3,38,11-q*3,-9-67*e,4,fx.edge);
   pulse(20+q*68,.33,6*(1-q)+1);
   for(let i=0;i<4;i++)stroke((i-1.5)*17,24+(i%2)*8,(i-1.5)*28,31+q*26,2.5);
  }else if(fx.kind==='LHL'){
   // Contra-corte: crisp X crossing at the exact contact point.
   const size=28+q*43;
   stroke(-size,-size*.65,size,size*.65,10-q*5);
   stroke(-size,size*.65,size,-size*.65,8-q*4,fx.edge);
   pulse(13+q*35,.42,2.7);
  }else if(fx.kind==='LHH'){
   // Martelo duplo: two displaced shock impacts with independent timing.
   for(let i=0;i<2;i++){const t=clamp((q-i*.19)/.8,0,1);if(q<i*.19)continue;ctx.save();ctx.translate((i?1:-1)*22,0);ctx.globalAlpha*=1-t;pulse(16+t*55,.42,7-4*t,i?fx.edge:fx.color);stroke(-7,-48*(1-t),6,19,6*(1-t)+2);ctx.restore();}
  }else if(fx.kind==='HLL'){
   // Rajada: multiple staggered and separated short diagonal cuts.
   for(let i=0;i<6;i++){const t=clamp((q-i*.075)/.65,0,1);if(q<i*.075)continue;const x=-35+i*14,y=(i%2?-1:1)*21;ctx.save();ctx.globalAlpha*=1-t;stroke(x-19,y-27,x+18+t*12,y+25,5-i*.38,i%2?fx.edge:fx.color);ctx.restore();}
  }else if(fx.kind==='HLH'){
   // Execução: a focused downward blade, fractured floor and delayed expanding blast.
   stroke(0,-102+q*88,0,37,15-q*7,fx.edge);
   stroke(-11,-94+q*79,7,31,5,fx.color);
   pulse(12+q*88,.30,8*(1-q)+1);
   for(let i=-2;i<=2;i++)stroke(i*12,30,i*19,37+q*(18+Math.abs(i)*10),2.5);
  }else if(fx.kind==='HH'){
   // Golpe duplo: tightly grouped concentric shockwaves, offset in time.
   pulse(18+q*63,.47,8*(1-q)+1);
   if(q>.15)pulse(9+(q-.15)*58,.47,5*(1-q)+1,fx.edge);
   stroke(-32,9,35,-15,8-q*5);
  }else if(fx.kind==='RIP_H'||fx.kind==='RIP_L'){
   // Counterattack: brilliant teal diamond shatter, not the same as a regular finisher.
   const r=18+q*42;
   for(let i=0;i<4;i++){const a=i*PI*.5;stroke(Math.cos(a)*10,Math.sin(a)*10,Math.cos(a)*r,Math.sin(a)*r,5-q*2,i%2?fx.edge:fx.color);}
   ctx.strokeStyle=fx.edge;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(0,-r);ctx.lineTo(r,0);ctx.lineTo(0,r);ctx.lineTo(-r,0);ctx.closePath();ctx.stroke();
   pulse(17+q*46,.40,3.8);
  }
  ctx.restore();
 }
}
function visualEffects(){for(const r of rings){const p=point(r.x,r.z),t=1-r.life/r.max;ctx.save();ctx.globalAlpha=(1-t)*.85;ctx.strokeStyle=r.color;ctx.lineWidth=r.power*2.2*(1-t)+.5;ctx.beginPath();ctx.ellipse(p.x,p.y,r.r+t*43*r.power,(r.r+t*43*r.power)*.45,0,0,TAU);ctx.stroke();ctx.restore();}
 for(const f of flashes){const p=point(f.x,f.z),t=1-f.life/f.max,rad=22+t*62*f.power;ctx.save();ctx.globalAlpha=(1-t)*.58;const g=ctx.createRadialGradient(p.x,p.y-26,0,p.x,p.y-26,rad);g.addColorStop(0,'#ffffff');g.addColorStop(.22,f.color);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y-26,rad,0,TAU);ctx.fill();ctx.restore();}
 for(const part of particles){const p=point(part.x,part.z),alpha=clamp(part.life/part.max,0,1);ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle=part.color;ctx.fillStyle=part.color;ctx.shadowColor=part.color;ctx.shadowBlur=part.trail?8:4;if(part.trail){ctx.lineWidth=part.size;ctx.beginPath();ctx.moveTo(p.x,p.y-part.y);ctx.lineTo(p.x-part.vx*3.8,p.y-part.y+part.vy*.034);ctx.stroke();}else{ctx.beginPath();ctx.arc(p.x,p.y-part.y,part.size,0,TAU);ctx.fill();}ctx.restore();}
 for(const t of texts){const p=point(t.x,t.z);ctx.save();ctx.globalAlpha=clamp(t.life/.23,0,1);ctx.font=`1000 ${t.size}px system-ui`;ctx.textAlign='center';ctx.shadowColor='#000';ctx.shadowBlur=8;ctx.fillStyle=t.color;ctx.fillText(t.t,p.x,p.y-t.y);ctx.restore();}}
function drawReachGuide(){
 if(!settings.showReach||!player?.act)return;
 const a=player.act,m=a.move,progress=a.time/m.dur,b=activeInterval(m);
 const p=point(player.x,player.z),d=point(player.x+player.face.x,player.z+player.face.z);
 const forwardAngle=Math.atan2(d.y-p.y,d.x-p.x);
 ctx.save();ctx.globalAlpha=.8;ctx.strokeStyle='#9af9da';ctx.setLineDash([5,5]);ctx.lineWidth=1.5;
 let old=null;
 for(let i=0;i<=24;i++){const dir=rotate(player.face,m.angle*mix(-1.05,1.05,i/24)),pos=point(player.x+dir.x*m.reach,player.z+dir.z*m.reach);
   if(i===0)ctx.beginPath(),ctx.moveTo(pos.x,pos.y);else ctx.lineTo(pos.x,pos.y);
 }
 ctx.stroke();ctx.setLineDash([]);
 const tip=rotate(player.face,swingPose(m,progress).angle),pos=point(player.x+tip.x*m.reach,player.z+tip.z*m.reach);
 ctx.fillStyle=progress>=b.start&&progress<=b.end?'#92ffd6':'#c3d4dd';ctx.beginPath();ctx.arc(pos.x,pos.y,5,0,TAU);ctx.fill();
 ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillStyle='#d2ffeb';ctx.fillText(progress<b.start?'PREPARAÇÃO':progress>b.end?'RECUPERAÇÃO':'CORTE ATIVO',p.x,p.y-102);
 ctx.restore();
}

function tacticalVisual(){
 if(!tacticalOn())return;
 ctx.save();
 for(const g of living()){
  if(g.guardAlly&&g.phase==='guard'&&g.guardTime>0){
   const ally=living().find(a=>a.id===g.guardAlly);
   if(!ally)continue;
   const a=point(g.x,g.z),b=point(ally.x,ally.z);
   ctx.save();ctx.globalAlpha=.45+.25*Math.sin(clock*8);ctx.strokeStyle='#8effe4';ctx.lineWidth=4;ctx.setLineDash([7,6]);ctx.beginPath();ctx.moveTo(a.x,a.y-28);ctx.lineTo(b.x,b.y-26);ctx.stroke();ctx.setLineDash([]);
   ctx.fillStyle='#b6ffec';ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillText('🛡 COBERTURA',(a.x+b.x)/2,(a.y+b.y)/2-40);ctx.restore();
  }
  if(g.role==='flanco'&&g.flankCooldown<=0&&g.phase==='chase'&&length(g.x-player.x,g.z-player.z)<4.8){
   const side=rotate(player.face,g.flankSide*2.12),loc=point(player.x+side.x*2,player.z+side.z*2),from=point(g.x,g.z);
   ctx.save();ctx.globalAlpha=.22+.10*Math.sin(clock*5);ctx.setLineDash([4,6]);ctx.lineWidth=2;ctx.strokeStyle='#c2a1ff';ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(loc.x,loc.y);ctx.stroke();ctx.setLineDash([]);
   ctx.beginPath();ctx.ellipse(loc.x,loc.y,14,7,0,0,TAU);ctx.stroke();ctx.restore();
  }
 }
 const nearThreats=living().filter(e=>['windup','strike','feint'].includes(e.phase)&&length(e.x-player.x,e.z-player.z)<4.8);
 const hero=point(player.x,player.z);
 for(const e of nearThreats){
  const dir=unit(e.x-player.x,e.z-player.z),where=point(player.x+dir.x*1.2,player.z+dir.z*1.2),angle=Math.atan2(where.y-hero.y,where.x-hero.x);
  ctx.save();ctx.translate(where.x,where.y-22);ctx.rotate(angle);
  ctx.fillStyle=e.phase==='feint'?'#cdadff':e.type==='heavy'?'#ffce7b':'#ff827b';ctx.shadowBlur=8;ctx.shadowColor=ctx.fillStyle;
  ctx.beginPath();ctx.moveTo(13,0);ctx.lineTo(-8,-6);ctx.lineTo(-8,6);ctx.closePath();ctx.fill();ctx.restore();
 }
 ctx.restore();
}
function render(){ctx.setTransform(dpr,0,0,dpr,0,0);ctx.save();if(shake>.15&&!settings.reducedMotion)ctx.translate(rnd(-shake*.62,shake*.62),rnd(-shake*.32,shake*.32));ground();aimVisual();tacticalVisual();warning();drawReachGuide();const actors=[{u:player,team:'player'},...enemies.map(u=>({u,team:'enemy'}))].sort((a,b)=>(a.u.x+a.u.z)-(b.u.x+b.u.z));for(const a of actors)figure(a.u,a.team);traces();visualEffects();specialEffects();if(screenFlash>0&&!settings.reducedMotion){ctx.fillStyle=`rgba(255,255,255,${screenFlash*.22})`;ctx.fillRect(0,0,w,h);}ctx.restore();}
